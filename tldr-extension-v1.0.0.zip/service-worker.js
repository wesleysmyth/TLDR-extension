const scriptRel = 'modulepreload';const assetsURL = function(dep, importerUrl) { return new URL(dep, importerUrl).href };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (true && deps && deps.length > 0) {
    const links = document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep, importerUrl);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        const isBaseRelative = !!importerUrl;
        if (isBaseRelative) {
          for (let i = links.length - 1; i >= 0; i--) {
            const link2 = links[i];
            if (link2.href === dep && (!isCss || link2.rel === "stylesheet")) {
              return;
            }
          }
        } else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};

/**
 * TLDR Extension - Storage Wrapper
 * Handles settings persistence and summary caching
 */

const STORAGE_KEYS = {
  SETTINGS: 'tldr_settings',
  SUMMARY_CACHE: 'tldr_cache',
};

const DEFAULT_SETTINGS = {
  // AI Provider preference
  provider: 'auto', // 'auto', 'chrome', 'groq'
  groqApiKey: null,

  // Cache settings
  enableCache: true,
  cacheExpiry: 24 * 60 * 60 * 1000, // 24 hours in ms

  // Variation settings for summary customization
  tone: 'witty',           // 'witty', 'professional', 'casual', 'academic'
  length: 'brief',         // 'one-liner', 'brief', 'detailed'
  focus: 'key-facts',      // 'key-facts', 'opinions', 'implications'
  creativity: 'balanced',  // 'consistent', 'balanced', 'creative'

  // UI preferences
  theme: 'system',
};

const MAX_CACHE_ENTRIES = 100;

/**
 * Storage wrapper for Chrome extension storage APIs
 */
const storage = {
  /**
   * Get user settings
   * @returns {Promise<Object>} Settings object with defaults applied
   */
  async getSettings() {
    try {
      const result = await chrome.storage.sync.get(STORAGE_KEYS.SETTINGS);
      return { ...DEFAULT_SETTINGS, ...result[STORAGE_KEYS.SETTINGS] };
    } catch (error) {
      console.error('[TLDR] Failed to load settings:', error);
      return { ...DEFAULT_SETTINGS };
    }
  },

  /**
   * Save user settings
   * @param {Object} settings - Settings to save (merged with existing)
   */
  async setSettings(settings) {
    try {
      const current = await this.getSettings();
      const merged = { ...current, ...settings };
      await chrome.storage.sync.set({ [STORAGE_KEYS.SETTINGS]: merged });
    } catch (error) {
      console.error('[TLDR] Failed to save settings:', error);
      throw error;
    }
  },

  /**
   * Get cached summary for a URL
   * @param {string} url - Page URL
   * @returns {Promise<Object|null>} Cached summary or null
   */
  async getCachedSummary(url) {
    try {
      const settings = await this.getSettings();
      if (!settings.enableCache) return null;

      const result = await chrome.storage.local.get(STORAGE_KEYS.SUMMARY_CACHE);
      const cache = result[STORAGE_KEYS.SUMMARY_CACHE] || {};

      const cacheKey = this._hashUrl(url);
      const entry = cache[cacheKey];

      if (!entry) return null;

      // Check if expired
      if (Date.now() - entry.timestamp > settings.cacheExpiry) {
        // Clean up expired entry
        delete cache[cacheKey];
        await chrome.storage.local.set({ [STORAGE_KEYS.SUMMARY_CACHE]: cache });
        return null;
      }

      return entry.data;
    } catch (error) {
      console.error('[TLDR] Failed to get cached summary:', error);
      return null;
    }
  },

  /**
   * Cache a summary for a URL
   * @param {string} url - Page URL
   * @param {Object} data - Summary data to cache
   */
  async cacheSummary(url, data) {
    try {
      const settings = await this.getSettings();
      if (!settings.enableCache) return;

      const result = await chrome.storage.local.get(STORAGE_KEYS.SUMMARY_CACHE);
      const cache = result[STORAGE_KEYS.SUMMARY_CACHE] || {};

      // Enforce max cache size
      const keys = Object.keys(cache);
      if (keys.length >= MAX_CACHE_ENTRIES) {
        // Remove oldest entry
        const oldest = keys.reduce((a, b) =>
          cache[a].timestamp < cache[b].timestamp ? a : b
        );
        delete cache[oldest];
      }

      const cacheKey = this._hashUrl(url);
      cache[cacheKey] = {
        data,
        timestamp: Date.now(),
        url, // Store original URL for debugging
      };

      await chrome.storage.local.set({ [STORAGE_KEYS.SUMMARY_CACHE]: cache });
    } catch (error) {
      console.error('[TLDR] Failed to cache summary:', error);
    }
  },

  /**
   * Clear all cached summaries
   */
  async clearCache() {
    try {
      await chrome.storage.local.remove(STORAGE_KEYS.SUMMARY_CACHE);
    } catch (error) {
      console.error('[TLDR] Failed to clear cache:', error);
      throw error;
    }
  },

  /**
   * Get cache statistics
   * @returns {Promise<Object>} Cache stats
   */
  async getCacheStats() {
    try {
      const result = await chrome.storage.local.get(STORAGE_KEYS.SUMMARY_CACHE);
      const cache = result[STORAGE_KEYS.SUMMARY_CACHE] || {};
      const entries = Object.values(cache);

      return {
        count: entries.length,
        maxEntries: MAX_CACHE_ENTRIES,
        oldestEntry: entries.length
          ? new Date(Math.min(...entries.map((e) => e.timestamp)))
          : null,
        newestEntry: entries.length
          ? new Date(Math.max(...entries.map((e) => e.timestamp)))
          : null,
      };
    } catch (error) {
      console.error('[TLDR] Failed to get cache stats:', error);
      return { count: 0, maxEntries: MAX_CACHE_ENTRIES };
    }
  },

  /**
   * Simple hash function for URLs (for cache keys)
   * @private
   */
  _hashUrl(url) {
    let hash = 0;
    for (let i = 0; i < url.length; i++) {
      const char = url.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return 'url_' + Math.abs(hash).toString(36);
  },
};

/**
 * TLDR Extension - Summary Prompts
 * Configurable prompts with variation parameters for personalized summaries
 *
 * TUNED based on variation test results (34 articles, 283 API calls):
 * - Length presets adjusted to hit word count targets
 * - Opening variety emphasized to avoid "[Topic] is..." patterns
 * - Examples updated to demonstrate varied sentence structures
 */

// ============================================
// Variation Presets
// ============================================

const TONE_PRESETS = {
  witty: {
    name: 'Witty',
    description: 'Clever and engaging with wordplay',
    instruction: 'Be clever and witty. Use wordplay, irony, or unexpected angles when they fit naturally. Make the reader smile.',
    examples: [
      'Scientists confirmed what cat owners always suspected: your pet is definitely ignoring you on purpose.',
      'Turns out "move fast and break things" works better as a startup motto than a legal defense.',
      'Your brain literally cleans house while you sleep – scrubbing away waste like a night-shift janitor.',
    ],
  },
  professional: {
    name: 'Professional',
    description: 'Clear and authoritative',
    instruction: 'Be clear, authoritative, and precise. Write for a business or professional context. Focus on accuracy and clarity.',
    examples: [
      'New research demonstrates a 47% improvement in battery efficiency using solid-state technology.',
      'Market analysis indicates sustained growth in the renewable energy sector through 2030.',
      'Recent findings challenge conventional assumptions about remote work productivity metrics.',
    ],
  },
  casual: {
    name: 'Casual',
    description: 'Friendly and conversational',
    instruction: 'Be friendly and conversational. Write like you\'re telling a friend about something interesting you read.',
    examples: [
      'So basically, they figured out how to make batteries last way longer - pretty cool stuff.',
      'Turns out getting enough sleep is even more important than we thought. Who knew?',
      'Here\'s a wild one: scientists just proved that plants can actually "hear" themselves being eaten.',
    ],
  },
  academic: {
    name: 'Academic',
    description: 'Scholarly and nuanced',
    instruction: 'Be scholarly and nuanced. Acknowledge complexity, use precise terminology, and maintain intellectual rigor.',
    examples: [
      'The study presents compelling evidence for neuroplasticity in adult subjects, challenging prior assumptions.',
      'This analysis contributes to our understanding of market dynamics under asymmetric information conditions.',
      'Contemporary research reveals significant heterogeneity in treatment response across demographic cohorts.',
    ],
  },
};

// Length presets tuned based on test results:
// - Model tends to produce short outputs; aggressively specify minimums
// - Use stronger language: "MUST", "NEVER", "AT LEAST"
// - Specify sentence counts to force expansion
const LENGTH_PRESETS = {
  'one-liner': {
    name: 'One-liner',
    description: '~18-22 words',
    instruction: 'Write exactly ONE complete sentence with 18-22 words. NEVER use fewer than 18 words. If too short, add relevant context or detail.',
    maxTokens: 100,
    targetWords: 20,
  },
  brief: {
    name: 'Brief',
    description: '~30-40 words',
    instruction: 'Write EXACTLY 2-3 complete sentences totaling 30-40 words. You MUST use AT LEAST 30 words. If your first draft is shorter, expand with context, significance, or relevant details.',
    maxTokens: 200,
    targetWords: 35,
  },
  detailed: {
    name: 'Detailed',
    description: '~60-80 words',
    instruction: 'Write 4-5 complete sentences totaling 60-80 words. You MUST use AT LEAST 60 words. Cover: main point, key evidence/details, context, and implications. Expand with specifics.',
    maxTokens: 400,
    targetWords: 70,
  },
};

const FOCUS_PRESETS = {
  'key-facts': {
    name: 'Key Facts',
    description: 'Main factual takeaways',
    instruction: 'Focus on the most important factual information. Lead with concrete data, numbers, or verifiable claims. What are the headline facts?',
  },
  opinions: {
    name: 'Opinions',
    description: "Author's perspective",
    instruction: 'Focus on the author\'s perspective and arguments. What position are they advocating? What\'s their thesis? Capture their stance.',
  },
  implications: {
    name: 'Implications',
    description: 'Why it matters',
    instruction: 'Focus on implications and relevance. Lead with why the reader should care. What does this mean for them? What changes?',
  },
};

const CREATIVITY_PRESETS = {
  consistent: {
    name: 'Consistent',
    description: 'Predictable outputs',
    temperature: 0.3,
  },
  balanced: {
    name: 'Balanced',
    description: 'Moderate variety',
    temperature: 0.7,
  },
  creative: {
    name: 'Creative',
    description: 'More diverse',
    temperature: 1.0,
  },
};

// ============================================
// Default Settings
// ============================================

const DEFAULT_VARIATION_SETTINGS = {
  tone: 'witty',
  length: 'brief',
  focus: 'key-facts'};

// ============================================
// Prompt Builder
// ============================================

/**
 * Build the system prompt based on variation settings
 * @param {Object} settings - Variation settings
 * @returns {string} Constructed system prompt
 */
function buildSystemPrompt(settings = {}) {
  const {
    tone = 'witty',
    length = 'brief',
    focus = 'key-facts',
  } = settings;

  const tonePreset = TONE_PRESETS[tone] || TONE_PRESETS.witty;
  const lengthPreset = LENGTH_PRESETS[length] || LENGTH_PRESETS.brief;
  const focusPreset = FOCUS_PRESETS[focus] || FOCUS_PRESETS['key-facts'];

  const examples = tonePreset.examples
    .map(e => `- "${e}"`)
    .join('\n');

  return `You are TLDR, a brilliant summarizer that distills articles into their essence.

STYLE: ${tonePreset.instruction}

LENGTH: ${lengthPreset.instruction}

FOCUS: ${focusPreset.instruction}

CRITICAL RULES for your summaries:
1. HONEST: Never misrepresent or exaggerate the article's actual content
2. VARIED OPENINGS: NEVER start with "[Topic] is..." or "[Topic] are..." - this is boring and repetitive
3. ENGAGING: Capture attention from the first word
4. HIT THE WORD COUNT: You MUST meet the MINIMUM word count specified above. Count your words. If under the minimum, ADD more context, details, or implications until you reach it. Being too brief is a FAILURE.

Opening strategies (pick one):
- Lead with the most surprising finding or statistic
- Start with an action, consequence, or change happening
- Open with who/what is affected and how
- Begin with a contrast, irony, or unexpected angle

You MUST respond with valid JSON in this exact format:
{
  "summary": "Your summary here",
  "keyPoints": ["Key point 1", "Key point 2", "Key point 3"],
  "tone": "detected_tone"
}

The "tone" field should reflect the article's tone: informative, opinion, news, technical, entertainment, or analysis

Good examples of ${tonePreset.name.toLowerCase()} summaries (notice the VARIED openings):
${examples}

BAD patterns to NEVER use:
- "[Topic] is..." or "[Topic] are..." (boring, every AI does this)
- "This article discusses..." (passive, meta)
- "In this piece, the author..." (too formal, meta)
- "The key takeaways are..." (robotic, predictable)
- Starting multiple summaries the same way

Keep key points brief (under 15 words each). Aim for 3 points unless the article only has 1-2 main ideas.`;
}

// Legacy export for backwards compatibility
buildSystemPrompt(DEFAULT_VARIATION_SETTINGS);

const USER_PROMPT_TEMPLATE = `Summarize this article:

TITLE: {title}

CONTENT:
{content}`;

/**
 * Build the user prompt for summarization
 * @param {Object} article - Article data
 * @returns {string} Formatted prompt
 */
function buildUserPrompt(article) {
  // Truncate content to ~6000 chars to stay within token limits
  const maxContentLength = 6000;
  const content =
    article.content.length > maxContentLength
      ? article.content.slice(0, maxContentLength) + '...[truncated]'
      : article.content;

  return USER_PROMPT_TEMPLATE.replace('{title}', article.title).replace(
    '{content}',
    content
  );
}

/**
 * Get temperature value from creativity preset
 * @param {string} creativity - Creativity preset name
 * @returns {number} Temperature value
 */
function getTemperature(creativity = 'balanced') {
  return CREATIVITY_PRESETS[creativity]?.temperature ?? 0.7;
}

/**
 * Get max tokens from length preset
 * @param {string} length - Length preset name
 * @returns {number} Max tokens
 */
function getMaxTokens(length = 'brief') {
  return LENGTH_PRESETS[length]?.maxTokens ?? 200;
}

/**
 * TLDR Extension - Groq API Provider
 * Fast LLM inference using Groq's API (Llama 3.1)
 */


const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const DEFAULT_MODEL = 'llama-3.1-8b-instant';

/**
 * Groq API Provider for article summarization
 */
class GroqProvider {
  /**
   * @param {string} apiKey - Groq API key
   * @param {Object} variationSettings - Variation settings for summary customization
   */
  constructor(apiKey, variationSettings = {}) {
    this.name = 'Groq';
    this.apiKey = apiKey;
    this.variationSettings = variationSettings;
  }

  /**
   * Check if provider is available (has valid API key)
   * @returns {Promise<boolean>}
   */
  async isAvailable() {
    return Boolean(this.apiKey && this.apiKey.length > 0);
  }

  /**
   * Summarize article content using Groq API
   * @param {Object} article - Article data with title and content
   * @param {Object} options - Optional override settings
   * @returns {Promise<Object>} Summary result
   */
  async summarize(article, options = {}) {
    // Merge default variation settings with any overrides
    const settings = { ...this.variationSettings, ...options };

    const systemPrompt = buildSystemPrompt(settings);
    const userPrompt = buildUserPrompt(article);
    const temperature = getTemperature(settings.creativity);
    const maxTokens = getMaxTokens(settings.length);

    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: DEFAULT_MODEL,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature,
        max_tokens: maxTokens,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new GroqError(
        error.error?.message || `API request failed: ${response.status}`,
        response.status
      );
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new GroqError('Empty response from API', 500);
    }

    return this._parseResponse(content);
  }

  /**
   * Parse JSON response from Groq
   * @private
   */
  _parseResponse(content) {
    try {
      const parsed = JSON.parse(content);

      // Validate required fields
      if (!parsed.summary) {
        throw new Error('Missing summary field');
      }

      return {
        summary: parsed.summary,
        keyPoints: Array.isArray(parsed.keyPoints) ? parsed.keyPoints : [],
        tone: parsed.tone || 'informative',
      };
    } catch (error) {
      console.error('[TLDR] Failed to parse Groq response:', error);

      // Fallback: treat raw content as summary
      return {
        summary: content.slice(0, 500),
        keyPoints: [],
        tone: 'informative',
      };
    }
  }
}

/**
 * Custom error class for Groq API errors
 */
class GroqError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.name = 'GroqError';
    this.statusCode = statusCode;

    // Determine error type
    if (statusCode === 429) {
      this.code = 'rate_limited';
      this.title = 'Rate Limited';
      this.recoverable = true;
    } else if (statusCode === 401) {
      this.code = 'invalid_key';
      this.title = 'Invalid API Key';
      this.recoverable = false;
    } else if (statusCode >= 500) {
      this.code = 'server_error';
      this.title = 'Server Error';
      this.recoverable = true;
    } else {
      this.code = 'api_error';
      this.title = 'API Error';
      this.recoverable = true;
    }
  }
}

/**
 * TLDR Extension - AI Provider Factory
 * Simplified: Groq-only provider
 */


/**
 * Get the AI provider (Groq)
 * @param {Object} settings - User settings from storage (includes variation settings)
 * @returns {Promise<Object|null>} Provider instance or null if not configured
 */
async function getProvider(settings = {}) {
  if (settings.groqApiKey) {
    // Extract variation settings to pass to the provider
    const variationSettings = {
      tone: settings.tone || 'witty',
      length: settings.length || 'brief',
      focus: settings.focus || 'key-facts',
      creativity: settings.creativity || 'balanced',
    };
    return new GroqProvider(settings.groqApiKey, variationSettings);
  }
  return null;
}

/**
 * Check if Groq is configured
 * @param {Object} settings - User settings
 * @returns {Promise<Object>} Availability status
 */
async function checkProviderAvailability(settings = {}) {
  const hasGroq = Boolean(settings.groqApiKey);
  return {
    groq: hasGroq,
    hasAnyProvider: hasGroq,
  };
}

const ProviderErrorCodes = {
  NO_PROVIDER: 'no_provider'};

const provider = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  ProviderErrorCodes,
  checkProviderAvailability,
  getProvider
}, Symbol.toStringTag, { value: 'Module' }));

// ============================================
// Message Handler Registration
// IMPORTANT: Must be at top level for MV3
// ============================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle messages asynchronously
  handleMessage(message)
    .then(sendResponse)
    .catch((error) => {
      console.error('[TLDR] Message handler error:', error);
      sendResponse({
        success: false,
        error: {
          code: error.code || 'unknown',
          title: error.title || 'Error',
          message: error.message || 'An unexpected error occurred',
        },
      });
    });

  // Return true to indicate async response
  return true;
});

// ============================================
// Message Router
// ============================================

async function handleMessage(message, sender) {
  console.log('[TLDR] Received message:', message.type);

  switch (message.type) {
    case 'SUMMARIZE':
      return handleSummarize(message.article, message.forceRefresh);

    case 'GET_CACHED_SUMMARY':
      return handleGetCached(message.url);

    case 'GET_SETTINGS':
      return handleGetSettings();

    case 'SAVE_SETTINGS':
      return handleSaveSettings(message.settings);

    case 'CHECK_PROVIDERS':
      return handleCheckProviders();

    case 'CLEAR_CACHE':
      return handleClearCache();

    default:
      throw new Error(`Unknown message type: ${message.type}`);
  }
}

// ============================================
// Handlers
// ============================================

/**
 * Main summarization handler
 */
async function handleSummarize(article, forceRefresh = false) {
  const settings = await storage.getSettings();

  // Check cache first (unless forcing refresh)
  if (!forceRefresh) {
    const cached = await storage.getCachedSummary(article.url);
    if (cached) {
      console.log('[TLDR] Returning cached summary');
      return {
        success: true,
        data: {
          ...cached,
          fromCache: true,
        },
      };
    }
  }

  // Get AI provider
  const provider = await getProvider(settings);

  if (!provider) {
    return {
      success: false,
      error: {
        code: ProviderErrorCodes.NO_PROVIDER,
        title: 'Setup Required',
        message: 'Add your free Groq API key to start summarizing articles!',
      },
    };
  }

  try {
    // Generate summary
    console.log(`[TLDR] Summarizing with ${provider.name}...`);
    const summary = await provider.summarize(article);

    // Build response data
    const data = {
      article: {
        title: article.title,
        url: article.url,
        siteName: article.siteName,
        readingTime: article.readingTime,
      },
      summary,
      provider: provider.name,
      fromCache: false,
    };

    // Cache the result
    await storage.cacheSummary(article.url, data);

    return {
      success: true,
      data,
    };
  } catch (error) {
    console.error('[TLDR] Summarization failed:', error);

    // Clean up provider if needed
    if (typeof provider.destroy === 'function') {
      provider.destroy();
    }

    return {
      success: false,
      error: {
        code: error.code || 'summarize_failed',
        title: error.title || 'Summarization Failed',
        message: error.message || 'Failed to generate summary. Please try again.',
      },
    };
  }
}

/**
 * Get cached summary for URL
 */
async function handleGetCached(url) {
  const cached = await storage.getCachedSummary(url);

  if (cached) {
    return {
      success: true,
      data: {
        ...cached,
        fromCache: true,
      },
    };
  }

  return { success: false };
}

/**
 * Get current settings
 */
async function handleGetSettings() {
  const settings = await storage.getSettings();
  return { success: true, data: settings };
}

/**
 * Save settings
 */
async function handleSaveSettings(settings) {
  await storage.setSettings(settings);
  return { success: true };
}

/**
 * Check provider availability
 */
async function handleCheckProviders() {
  const settings = await storage.getSettings();
  const { checkProviderAvailability } = await __vitePreload(async () => { const { checkProviderAvailability } = await Promise.resolve().then(() => provider);return { checkProviderAvailability }},true?void 0:void 0,import.meta.url);
  const availability = await checkProviderAvailability(settings);

  return {
    success: true,
    data: availability,
  };
}

/**
 * Clear summary cache
 */
async function handleClearCache() {
  await storage.clearCache();
  return { success: true };
}

// ============================================
// Extension Events
// ============================================

// Handle extension installation/update
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[TLDR] Extension installed/updated:', details.reason);

  if (details.reason === 'install') {
    // First install - could show onboarding
    console.log('[TLDR] First install - welcome!');
  } else if (details.reason === 'update') {
    // Extension updated
    console.log('[TLDR] Updated from version:', details.previousVersion);
  }
});

// Log when service worker starts
console.log('[TLDR] Service worker initialized');
