var Readability$1 = {exports: {}};

/*
 * Copyright (c) 2010 Arc90 Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

(function (module) {
	/*
	 * This code is heavily based on Arc90's readability.js (1.7.1) script
	 * available at: http://code.google.com/p/arc90labs-readability
	 */

	/**
	 * Public constructor.
	 * @param {HTMLDocument} doc     The document to parse.
	 * @param {Object}       options The options object.
	 */
	function Readability(doc, options) {
	  // In some older versions, people passed a URI as the first argument. Cope:
	  if (options && options.documentElement) {
	    doc = options;
	    options = arguments[2];
	  } else if (!doc || !doc.documentElement) {
	    throw new Error(
	      "First argument to Readability constructor should be a document object."
	    );
	  }
	  options = options || {};

	  this._doc = doc;
	  this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
	  this._articleTitle = null;
	  this._articleByline = null;
	  this._articleDir = null;
	  this._articleSiteName = null;
	  this._attempts = [];
	  this._metadata = {};

	  // Configurable options
	  this._debug = !!options.debug;
	  this._maxElemsToParse =
	    options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
	  this._nbTopCandidates =
	    options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
	  this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
	  this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(
	    options.classesToPreserve || []
	  );
	  this._keepClasses = !!options.keepClasses;
	  this._serializer =
	    options.serializer ||
	    function (el) {
	      return el.innerHTML;
	    };
	  this._disableJSONLD = !!options.disableJSONLD;
	  this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
	  this._linkDensityModifier = options.linkDensityModifier || 0;

	  // Start with all flags set
	  this._flags =
	    this.FLAG_STRIP_UNLIKELYS |
	    this.FLAG_WEIGHT_CLASSES |
	    this.FLAG_CLEAN_CONDITIONALLY;

	  // Control whether log messages are sent to the console
	  if (this._debug) {
	    let logNode = function (node) {
	      if (node.nodeType == node.TEXT_NODE) {
	        return `${node.nodeName} ("${node.textContent}")`;
	      }
	      let attrPairs = Array.from(node.attributes || [], function (attr) {
	        return `${attr.name}="${attr.value}"`;
	      }).join(" ");
	      return `<${node.localName} ${attrPairs}>`;
	    };
	    this.log = function () {
	      if (typeof console !== "undefined") {
	        let args = Array.from(arguments, arg => {
	          if (arg && arg.nodeType == this.ELEMENT_NODE) {
	            return logNode(arg);
	          }
	          return arg;
	        });
	        args.unshift("Reader: (Readability)");
	        // eslint-disable-next-line no-console
	        console.log(...args);
	      } else if (typeof dump !== "undefined") {
	        /* global dump */
	        var msg = Array.prototype.map
	          .call(arguments, function (x) {
	            return x && x.nodeName ? logNode(x) : x;
	          })
	          .join(" ");
	        dump("Reader: (Readability) " + msg + "\n");
	      }
	    };
	  } else {
	    this.log = function () {};
	  }
	}

	Readability.prototype = {
	  FLAG_STRIP_UNLIKELYS: 0x1,
	  FLAG_WEIGHT_CLASSES: 0x2,
	  FLAG_CLEAN_CONDITIONALLY: 0x4,

	  // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
	  ELEMENT_NODE: 1,
	  TEXT_NODE: 3,

	  // Max number of nodes supported by this parser. Default: 0 (no limit)
	  DEFAULT_MAX_ELEMS_TO_PARSE: 0,

	  // The number of top candidates to consider when analysing how
	  // tight the competition is among candidates.
	  DEFAULT_N_TOP_CANDIDATES: 5,

	  // Element tags to score by default.
	  DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre"
	    .toUpperCase()
	    .split(","),

	  // The default number of chars an article must have in order to return a result
	  DEFAULT_CHAR_THRESHOLD: 500,

	  // All of the regular expressions in use within readability.
	  // Defined up here so we don't instantiate them repeatedly in loops.
	  REGEXPS: {
	    // NOTE: These two regular expressions are duplicated in
	    // Readability-readerable.js. Please keep both copies in sync.
	    unlikelyCandidates:
	      /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
	    okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,

	    positive:
	      /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
	    negative:
	      /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
	    extraneous:
	      /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
	    byline: /byline|author|dateline|writtenby|p-author/i,
	    replaceFonts: /<(\/?)font[^>]*>/gi,
	    normalize: /\s{2,}/g,
	    videos:
	      /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
	    shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
	    nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
	    prevLink: /(prev|earl|old|new|<|«)/i,
	    tokenize: /\W+/g,
	    whitespace: /^\s*$/,
	    hasContent: /\S$/,
	    hashUrl: /^#.+/,
	    srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
	    b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
	    // Commas as used in Latin, Sindhi, Chinese and various other scripts.
	    // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
	    commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
	    // See: https://schema.org/Article
	    jsonLdArticleTypes:
	      /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
	    // used to see if a node's content matches words commonly used for ad blocks or loading indicators
	    adWords:
	      /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
	    loadingWords:
	      /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu,
	  },

	  UNLIKELY_ROLES: [
	    "menu",
	    "menubar",
	    "complementary",
	    "navigation",
	    "alert",
	    "alertdialog",
	    "dialog",
	  ],

	  DIV_TO_P_ELEMS: new Set([
	    "BLOCKQUOTE",
	    "DL",
	    "DIV",
	    "IMG",
	    "OL",
	    "P",
	    "PRE",
	    "TABLE",
	    "UL",
	  ]),

	  ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P", "OL", "UL"],

	  PRESENTATIONAL_ATTRIBUTES: [
	    "align",
	    "background",
	    "bgcolor",
	    "border",
	    "cellpadding",
	    "cellspacing",
	    "frame",
	    "hspace",
	    "rules",
	    "style",
	    "valign",
	    "vspace",
	  ],

	  DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],

	  // The commented out elements qualify as phrasing content but tend to be
	  // removed by readability when put into paragraphs, so we ignore them here.
	  PHRASING_ELEMS: [
	    // "CANVAS", "IFRAME", "SVG", "VIDEO",
	    "ABBR",
	    "AUDIO",
	    "B",
	    "BDO",
	    "BR",
	    "BUTTON",
	    "CITE",
	    "CODE",
	    "DATA",
	    "DATALIST",
	    "DFN",
	    "EM",
	    "EMBED",
	    "I",
	    "IMG",
	    "INPUT",
	    "KBD",
	    "LABEL",
	    "MARK",
	    "MATH",
	    "METER",
	    "NOSCRIPT",
	    "OBJECT",
	    "OUTPUT",
	    "PROGRESS",
	    "Q",
	    "RUBY",
	    "SAMP",
	    "SCRIPT",
	    "SELECT",
	    "SMALL",
	    "SPAN",
	    "STRONG",
	    "SUB",
	    "SUP",
	    "TEXTAREA",
	    "TIME",
	    "VAR",
	    "WBR",
	  ],

	  // These are the classes that readability sets itself.
	  CLASSES_TO_PRESERVE: ["page"],

	  // These are the list of HTML entities that need to be escaped.
	  HTML_ESCAPE_MAP: {
	    lt: "<",
	    gt: ">",
	    amp: "&",
	    quot: '"',
	    apos: "'",
	  },

	  /**
	   * Run any post-process modifications to article content as necessary.
	   *
	   * @param Element
	   * @return void
	   **/
	  _postProcessContent(articleContent) {
	    // Readability cannot open relative uris so we convert them to absolute uris.
	    this._fixRelativeUris(articleContent);

	    this._simplifyNestedElements(articleContent);

	    if (!this._keepClasses) {
	      // Remove classes.
	      this._cleanClasses(articleContent);
	    }
	  },

	  /**
	   * Iterates over a NodeList, calls `filterFn` for each node and removes node
	   * if function returned `true`.
	   *
	   * If function is not passed, removes all the nodes in node list.
	   *
	   * @param NodeList nodeList The nodes to operate on
	   * @param Function filterFn the function to use as a filter
	   * @return void
	   */
	  _removeNodes(nodeList, filterFn) {
	    // Avoid ever operating on live node lists.
	    if (this._docJSDOMParser && nodeList._isLiveNodeList) {
	      throw new Error("Do not pass live node lists to _removeNodes");
	    }
	    for (var i = nodeList.length - 1; i >= 0; i--) {
	      var node = nodeList[i];
	      var parentNode = node.parentNode;
	      if (parentNode) {
	        if (!filterFn || filterFn.call(this, node, i, nodeList)) {
	          parentNode.removeChild(node);
	        }
	      }
	    }
	  },

	  /**
	   * Iterates over a NodeList, and calls _setNodeTag for each node.
	   *
	   * @param NodeList nodeList The nodes to operate on
	   * @param String newTagName the new tag name to use
	   * @return void
	   */
	  _replaceNodeTags(nodeList, newTagName) {
	    // Avoid ever operating on live node lists.
	    if (this._docJSDOMParser && nodeList._isLiveNodeList) {
	      throw new Error("Do not pass live node lists to _replaceNodeTags");
	    }
	    for (const node of nodeList) {
	      this._setNodeTag(node, newTagName);
	    }
	  },

	  /**
	   * Iterate over a NodeList, which doesn't natively fully implement the Array
	   * interface.
	   *
	   * For convenience, the current object context is applied to the provided
	   * iterate function.
	   *
	   * @param  NodeList nodeList The NodeList.
	   * @param  Function fn       The iterate function.
	   * @return void
	   */
	  _forEachNode(nodeList, fn) {
	    Array.prototype.forEach.call(nodeList, fn, this);
	  },

	  /**
	   * Iterate over a NodeList, and return the first node that passes
	   * the supplied test function
	   *
	   * For convenience, the current object context is applied to the provided
	   * test function.
	   *
	   * @param  NodeList nodeList The NodeList.
	   * @param  Function fn       The test function.
	   * @return void
	   */
	  _findNode(nodeList, fn) {
	    return Array.prototype.find.call(nodeList, fn, this);
	  },

	  /**
	   * Iterate over a NodeList, return true if any of the provided iterate
	   * function calls returns true, false otherwise.
	   *
	   * For convenience, the current object context is applied to the
	   * provided iterate function.
	   *
	   * @param  NodeList nodeList The NodeList.
	   * @param  Function fn       The iterate function.
	   * @return Boolean
	   */
	  _someNode(nodeList, fn) {
	    return Array.prototype.some.call(nodeList, fn, this);
	  },

	  /**
	   * Iterate over a NodeList, return true if all of the provided iterate
	   * function calls return true, false otherwise.
	   *
	   * For convenience, the current object context is applied to the
	   * provided iterate function.
	   *
	   * @param  NodeList nodeList The NodeList.
	   * @param  Function fn       The iterate function.
	   * @return Boolean
	   */
	  _everyNode(nodeList, fn) {
	    return Array.prototype.every.call(nodeList, fn, this);
	  },

	  _getAllNodesWithTag(node, tagNames) {
	    if (node.querySelectorAll) {
	      return node.querySelectorAll(tagNames.join(","));
	    }
	    return [].concat.apply(
	      [],
	      tagNames.map(function (tag) {
	        var collection = node.getElementsByTagName(tag);
	        return Array.isArray(collection) ? collection : Array.from(collection);
	      })
	    );
	  },

	  /**
	   * Removes the class="" attribute from every element in the given
	   * subtree, except those that match CLASSES_TO_PRESERVE and
	   * the classesToPreserve array from the options object.
	   *
	   * @param Element
	   * @return void
	   */
	  _cleanClasses(node) {
	    var classesToPreserve = this._classesToPreserve;
	    var className = (node.getAttribute("class") || "")
	      .split(/\s+/)
	      .filter(cls => classesToPreserve.includes(cls))
	      .join(" ");

	    if (className) {
	      node.setAttribute("class", className);
	    } else {
	      node.removeAttribute("class");
	    }

	    for (node = node.firstElementChild; node; node = node.nextElementSibling) {
	      this._cleanClasses(node);
	    }
	  },

	  /**
	   * Tests whether a string is a URL or not.
	   *
	   * @param {string} str The string to test
	   * @return {boolean} true if str is a URL, false if not
	   */
	  _isUrl(str) {
	    try {
	      new URL(str);
	      return true;
	    } catch {
	      return false;
	    }
	  },
	  /**
	   * Converts each <a> and <img> uri in the given element to an absolute URI,
	   * ignoring #ref URIs.
	   *
	   * @param Element
	   * @return void
	   */
	  _fixRelativeUris(articleContent) {
	    var baseURI = this._doc.baseURI;
	    var documentURI = this._doc.documentURI;
	    function toAbsoluteURI(uri) {
	      // Leave hash links alone if the base URI matches the document URI:
	      if (baseURI == documentURI && uri.charAt(0) == "#") {
	        return uri;
	      }

	      // Otherwise, resolve against base URI:
	      try {
	        return new URL(uri, baseURI).href;
	      } catch (ex) {
	        // Something went wrong, just return the original:
	      }
	      return uri;
	    }

	    var links = this._getAllNodesWithTag(articleContent, ["a"]);
	    this._forEachNode(links, function (link) {
	      var href = link.getAttribute("href");
	      if (href) {
	        // Remove links with javascript: URIs, since
	        // they won't work after scripts have been removed from the page.
	        if (href.indexOf("javascript:") === 0) {
	          // if the link only contains simple text content, it can be converted to a text node
	          if (
	            link.childNodes.length === 1 &&
	            link.childNodes[0].nodeType === this.TEXT_NODE
	          ) {
	            var text = this._doc.createTextNode(link.textContent);
	            link.parentNode.replaceChild(text, link);
	          } else {
	            // if the link has multiple children, they should all be preserved
	            var container = this._doc.createElement("span");
	            while (link.firstChild) {
	              container.appendChild(link.firstChild);
	            }
	            link.parentNode.replaceChild(container, link);
	          }
	        } else {
	          link.setAttribute("href", toAbsoluteURI(href));
	        }
	      }
	    });

	    var medias = this._getAllNodesWithTag(articleContent, [
	      "img",
	      "picture",
	      "figure",
	      "video",
	      "audio",
	      "source",
	    ]);

	    this._forEachNode(medias, function (media) {
	      var src = media.getAttribute("src");
	      var poster = media.getAttribute("poster");
	      var srcset = media.getAttribute("srcset");

	      if (src) {
	        media.setAttribute("src", toAbsoluteURI(src));
	      }

	      if (poster) {
	        media.setAttribute("poster", toAbsoluteURI(poster));
	      }

	      if (srcset) {
	        var newSrcset = srcset.replace(
	          this.REGEXPS.srcsetUrl,
	          function (_, p1, p2, p3) {
	            return toAbsoluteURI(p1) + (p2 || "") + p3;
	          }
	        );

	        media.setAttribute("srcset", newSrcset);
	      }
	    });
	  },

	  _simplifyNestedElements(articleContent) {
	    var node = articleContent;

	    while (node) {
	      if (
	        node.parentNode &&
	        ["DIV", "SECTION"].includes(node.tagName) &&
	        !(node.id && node.id.startsWith("readability"))
	      ) {
	        if (this._isElementWithoutContent(node)) {
	          node = this._removeAndGetNext(node);
	          continue;
	        } else if (
	          this._hasSingleTagInsideElement(node, "DIV") ||
	          this._hasSingleTagInsideElement(node, "SECTION")
	        ) {
	          var child = node.children[0];
	          for (var i = 0; i < node.attributes.length; i++) {
	            child.setAttributeNode(node.attributes[i].cloneNode());
	          }
	          node.parentNode.replaceChild(child, node);
	          node = child;
	          continue;
	        }
	      }

	      node = this._getNextNode(node);
	    }
	  },

	  /**
	   * Get the article title as an H1.
	   *
	   * @return string
	   **/
	  _getArticleTitle() {
	    var doc = this._doc;
	    var curTitle = "";
	    var origTitle = "";

	    try {
	      curTitle = origTitle = doc.title.trim();

	      // If they had an element with id "title" in their HTML
	      if (typeof curTitle !== "string") {
	        curTitle = origTitle = this._getInnerText(
	          doc.getElementsByTagName("title")[0]
	        );
	      }
	    } catch (e) {
	      /* ignore exceptions setting the title. */
	    }

	    var titleHadHierarchicalSeparators = false;
	    function wordCount(str) {
	      return str.split(/\s+/).length;
	    }

	    // If there's a separator in the title, first remove the final part
	    if (/ [\|\-\\\/>»] /.test(curTitle)) {
	      titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
	      let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
	      curTitle = origTitle.substring(0, allSeparators.pop().index);

	      // If the resulting title is too short, remove the first part instead:
	      if (wordCount(curTitle) < 3) {
	        curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
	      }
	    } else if (curTitle.includes(": ")) {
	      // Check if we have an heading containing this exact string, so we
	      // could assume it's the full title.
	      var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
	      var trimmedTitle = curTitle.trim();
	      var match = this._someNode(headings, function (heading) {
	        return heading.textContent.trim() === trimmedTitle;
	      });

	      // If we don't, let's extract the title out of the original title string.
	      if (!match) {
	        curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);

	        // If the title is now too short, try the first colon instead:
	        if (wordCount(curTitle) < 3) {
	          curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
	          // But if we have too many words before the colon there's something weird
	          // with the titles and the H tags so let's just use the original title instead
	        } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
	          curTitle = origTitle;
	        }
	      }
	    } else if (curTitle.length > 150 || curTitle.length < 15) {
	      var hOnes = doc.getElementsByTagName("h1");

	      if (hOnes.length === 1) {
	        curTitle = this._getInnerText(hOnes[0]);
	      }
	    }

	    curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
	    // If we now have 4 words or fewer as our title, and either no
	    // 'hierarchical' separators (\, /, > or ») were found in the original
	    // title or we decreased the number of words by more than 1 word, use
	    // the original title.
	    var curTitleWordCount = wordCount(curTitle);
	    if (
	      curTitleWordCount <= 4 &&
	      (!titleHadHierarchicalSeparators ||
	        curTitleWordCount !=
	          wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)
	    ) {
	      curTitle = origTitle;
	    }

	    return curTitle;
	  },

	  /**
	   * Prepare the HTML document for readability to scrape it.
	   * This includes things like stripping javascript, CSS, and handling terrible markup.
	   *
	   * @return void
	   **/
	  _prepDocument() {
	    var doc = this._doc;

	    // Remove all style tags in head
	    this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));

	    if (doc.body) {
	      this._replaceBrs(doc.body);
	    }

	    this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
	  },

	  /**
	   * Finds the next node, starting from the given node, and ignoring
	   * whitespace in between. If the given node is an element, the same node is
	   * returned.
	   */
	  _nextNode(node) {
	    var next = node;
	    while (
	      next &&
	      next.nodeType != this.ELEMENT_NODE &&
	      this.REGEXPS.whitespace.test(next.textContent)
	    ) {
	      next = next.nextSibling;
	    }
	    return next;
	  },

	  /**
	   * Replaces 2 or more successive <br> elements with a single <p>.
	   * Whitespace between <br> elements are ignored. For example:
	   *   <div>foo<br>bar<br> <br><br>abc</div>
	   * will become:
	   *   <div>foo<br>bar<p>abc</p></div>
	   */
	  _replaceBrs(elem) {
	    this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function (br) {
	      var next = br.nextSibling;

	      // Whether 2 or more <br> elements have been found and replaced with a
	      // <p> block.
	      var replaced = false;

	      // If we find a <br> chain, remove the <br>s until we hit another node
	      // or non-whitespace. This leaves behind the first <br> in the chain
	      // (which will be replaced with a <p> later).
	      while ((next = this._nextNode(next)) && next.tagName == "BR") {
	        replaced = true;
	        var brSibling = next.nextSibling;
	        next.remove();
	        next = brSibling;
	      }

	      // If we removed a <br> chain, replace the remaining <br> with a <p>. Add
	      // all sibling nodes as children of the <p> until we hit another <br>
	      // chain.
	      if (replaced) {
	        var p = this._doc.createElement("p");
	        br.parentNode.replaceChild(p, br);

	        next = p.nextSibling;
	        while (next) {
	          // If we've hit another <br><br>, we're done adding children to this <p>.
	          if (next.tagName == "BR") {
	            var nextElem = this._nextNode(next.nextSibling);
	            if (nextElem && nextElem.tagName == "BR") {
	              break;
	            }
	          }

	          if (!this._isPhrasingContent(next)) {
	            break;
	          }

	          // Otherwise, make this node a child of the new <p>.
	          var sibling = next.nextSibling;
	          p.appendChild(next);
	          next = sibling;
	        }

	        while (p.lastChild && this._isWhitespace(p.lastChild)) {
	          p.lastChild.remove();
	        }

	        if (p.parentNode.tagName === "P") {
	          this._setNodeTag(p.parentNode, "DIV");
	        }
	      }
	    });
	  },

	  _setNodeTag(node, tag) {
	    this.log("_setNodeTag", node, tag);
	    if (this._docJSDOMParser) {
	      node.localName = tag.toLowerCase();
	      node.tagName = tag.toUpperCase();
	      return node;
	    }

	    var replacement = node.ownerDocument.createElement(tag);
	    while (node.firstChild) {
	      replacement.appendChild(node.firstChild);
	    }
	    node.parentNode.replaceChild(replacement, node);
	    if (node.readability) {
	      replacement.readability = node.readability;
	    }

	    for (var i = 0; i < node.attributes.length; i++) {
	      replacement.setAttributeNode(node.attributes[i].cloneNode());
	    }
	    return replacement;
	  },

	  /**
	   * Prepare the article node for display. Clean out any inline styles,
	   * iframes, forms, strip extraneous <p> tags, etc.
	   *
	   * @param Element
	   * @return void
	   **/
	  _prepArticle(articleContent) {
	    this._cleanStyles(articleContent);

	    // Check for data tables before we continue, to avoid removing items in
	    // those tables, which will often be isolated even though they're
	    // visually linked to other content-ful elements (text, images, etc.).
	    this._markDataTables(articleContent);

	    this._fixLazyImages(articleContent);

	    // Clean out junk from the article content
	    this._cleanConditionally(articleContent, "form");
	    this._cleanConditionally(articleContent, "fieldset");
	    this._clean(articleContent, "object");
	    this._clean(articleContent, "embed");
	    this._clean(articleContent, "footer");
	    this._clean(articleContent, "link");
	    this._clean(articleContent, "aside");

	    // Clean out elements with little content that have "share" in their id/class combinations from final top candidates,
	    // which means we don't remove the top candidates even they have "share".

	    var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;

	    this._forEachNode(articleContent.children, function (topCandidate) {
	      this._cleanMatchedNodes(topCandidate, function (node, matchString) {
	        return (
	          this.REGEXPS.shareElements.test(matchString) &&
	          node.textContent.length < shareElementThreshold
	        );
	      });
	    });

	    this._clean(articleContent, "iframe");
	    this._clean(articleContent, "input");
	    this._clean(articleContent, "textarea");
	    this._clean(articleContent, "select");
	    this._clean(articleContent, "button");
	    this._cleanHeaders(articleContent);

	    // Do these last as the previous stuff may have removed junk
	    // that will affect these
	    this._cleanConditionally(articleContent, "table");
	    this._cleanConditionally(articleContent, "ul");
	    this._cleanConditionally(articleContent, "div");

	    // replace H1 with H2 as H1 should be only title that is displayed separately
	    this._replaceNodeTags(
	      this._getAllNodesWithTag(articleContent, ["h1"]),
	      "h2"
	    );

	    // Remove extra paragraphs
	    this._removeNodes(
	      this._getAllNodesWithTag(articleContent, ["p"]),
	      function (paragraph) {
	        // At this point, nasty iframes have been removed; only embedded video
	        // ones remain.
	        var contentElementCount = this._getAllNodesWithTag(paragraph, [
	          "img",
	          "embed",
	          "object",
	          "iframe",
	        ]).length;
	        return (
	          contentElementCount === 0 && !this._getInnerText(paragraph, false)
	        );
	      }
	    );

	    this._forEachNode(
	      this._getAllNodesWithTag(articleContent, ["br"]),
	      function (br) {
	        var next = this._nextNode(br.nextSibling);
	        if (next && next.tagName == "P") {
	          br.remove();
	        }
	      }
	    );

	    // Remove single-cell tables
	    this._forEachNode(
	      this._getAllNodesWithTag(articleContent, ["table"]),
	      function (table) {
	        var tbody = this._hasSingleTagInsideElement(table, "TBODY")
	          ? table.firstElementChild
	          : table;
	        if (this._hasSingleTagInsideElement(tbody, "TR")) {
	          var row = tbody.firstElementChild;
	          if (this._hasSingleTagInsideElement(row, "TD")) {
	            var cell = row.firstElementChild;
	            cell = this._setNodeTag(
	              cell,
	              this._everyNode(cell.childNodes, this._isPhrasingContent)
	                ? "P"
	                : "DIV"
	            );
	            table.parentNode.replaceChild(cell, table);
	          }
	        }
	      }
	    );
	  },

	  /**
	   * Initialize a node with the readability object. Also checks the
	   * className/id for special names to add to its score.
	   *
	   * @param Element
	   * @return void
	   **/
	  _initializeNode(node) {
	    node.readability = { contentScore: 0 };

	    switch (node.tagName) {
	      case "DIV":
	        node.readability.contentScore += 5;
	        break;

	      case "PRE":
	      case "TD":
	      case "BLOCKQUOTE":
	        node.readability.contentScore += 3;
	        break;

	      case "ADDRESS":
	      case "OL":
	      case "UL":
	      case "DL":
	      case "DD":
	      case "DT":
	      case "LI":
	      case "FORM":
	        node.readability.contentScore -= 3;
	        break;

	      case "H1":
	      case "H2":
	      case "H3":
	      case "H4":
	      case "H5":
	      case "H6":
	      case "TH":
	        node.readability.contentScore -= 5;
	        break;
	    }

	    node.readability.contentScore += this._getClassWeight(node);
	  },

	  _removeAndGetNext(node) {
	    var nextNode = this._getNextNode(node, true);
	    node.remove();
	    return nextNode;
	  },

	  /**
	   * Traverse the DOM from node to node, starting at the node passed in.
	   * Pass true for the second parameter to indicate this node itself
	   * (and its kids) are going away, and we want the next node over.
	   *
	   * Calling this in a loop will traverse the DOM depth-first.
	   *
	   * @param {Element} node
	   * @param {boolean} ignoreSelfAndKids
	   * @return {Element}
	   */
	  _getNextNode(node, ignoreSelfAndKids) {
	    // First check for kids if those aren't being ignored
	    if (!ignoreSelfAndKids && node.firstElementChild) {
	      return node.firstElementChild;
	    }
	    // Then for siblings...
	    if (node.nextElementSibling) {
	      return node.nextElementSibling;
	    }
	    // And finally, move up the parent chain *and* find a sibling
	    // (because this is depth-first traversal, we will have already
	    // seen the parent nodes themselves).
	    do {
	      node = node.parentNode;
	    } while (node && !node.nextElementSibling);
	    return node && node.nextElementSibling;
	  },

	  // compares second text to first one
	  // 1 = same text, 0 = completely different text
	  // works the way that it splits both texts into words and then finds words that are unique in second text
	  // the result is given by the lower length of unique parts
	  _textSimilarity(textA, textB) {
	    var tokensA = textA
	      .toLowerCase()
	      .split(this.REGEXPS.tokenize)
	      .filter(Boolean);
	    var tokensB = textB
	      .toLowerCase()
	      .split(this.REGEXPS.tokenize)
	      .filter(Boolean);
	    if (!tokensA.length || !tokensB.length) {
	      return 0;
	    }
	    var uniqTokensB = tokensB.filter(token => !tokensA.includes(token));
	    var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
	    return 1 - distanceB;
	  },

	  /**
	   * Checks whether an element node contains a valid byline
	   *
	   * @param node {Element}
	   * @param matchString {string}
	   * @return boolean
	   */
	  _isValidByline(node, matchString) {
	    var rel = node.getAttribute("rel");
	    var itemprop = node.getAttribute("itemprop");
	    var bylineLength = node.textContent.trim().length;

	    return (
	      (rel === "author" ||
	        (itemprop && itemprop.includes("author")) ||
	        this.REGEXPS.byline.test(matchString)) &&
	      !!bylineLength &&
	      bylineLength < 100
	    );
	  },

	  _getNodeAncestors(node, maxDepth) {
	    maxDepth = maxDepth || 0;
	    var i = 0,
	      ancestors = [];
	    while (node.parentNode) {
	      ancestors.push(node.parentNode);
	      if (maxDepth && ++i === maxDepth) {
	        break;
	      }
	      node = node.parentNode;
	    }
	    return ancestors;
	  },

	  /***
	   * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
	   *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
	   *
	   * @param page a document to run upon. Needs to be a full document, complete with body.
	   * @return Element
	   **/
	  /* eslint-disable-next-line complexity */
	  _grabArticle(page) {
	    this.log("**** grabArticle ****");
	    var doc = this._doc;
	    var isPaging = page !== null;
	    page = page ? page : this._doc.body;

	    // We can't grab an article if we don't have a page!
	    if (!page) {
	      this.log("No body found in document. Abort.");
	      return null;
	    }

	    var pageCacheHtml = page.innerHTML;

	    while (true) {
	      this.log("Starting grabArticle loop");
	      var stripUnlikelyCandidates = this._flagIsActive(
	        this.FLAG_STRIP_UNLIKELYS
	      );

	      // First, node prepping. Trash nodes that look cruddy (like ones with the
	      // class name "comment", etc), and turn divs into P tags where they have been
	      // used inappropriately (as in, where they contain no other block level elements.)
	      var elementsToScore = [];
	      var node = this._doc.documentElement;

	      let shouldRemoveTitleHeader = true;

	      while (node) {
	        if (node.tagName === "HTML") {
	          this._articleLang = node.getAttribute("lang");
	        }

	        var matchString = node.className + " " + node.id;

	        if (!this._isProbablyVisible(node)) {
	          this.log("Removing hidden node - " + matchString);
	          node = this._removeAndGetNext(node);
	          continue;
	        }

	        // User is not able to see elements applied with both "aria-modal = true" and "role = dialog"
	        if (
	          node.getAttribute("aria-modal") == "true" &&
	          node.getAttribute("role") == "dialog"
	        ) {
	          node = this._removeAndGetNext(node);
	          continue;
	        }

	        // If we don't have a byline yet check to see if this node is a byline; if it is store the byline and remove the node.
	        if (
	          !this._articleByline &&
	          !this._metadata.byline &&
	          this._isValidByline(node, matchString)
	        ) {
	          // Find child node matching [itemprop="name"] and use that if it exists for a more accurate author name byline
	          var endOfSearchMarkerNode = this._getNextNode(node, true);
	          var next = this._getNextNode(node);
	          var itemPropNameNode = null;
	          while (next && next != endOfSearchMarkerNode) {
	            var itemprop = next.getAttribute("itemprop");
	            if (itemprop && itemprop.includes("name")) {
	              itemPropNameNode = next;
	              break;
	            } else {
	              next = this._getNextNode(next);
	            }
	          }
	          this._articleByline = (itemPropNameNode ?? node).textContent.trim();
	          node = this._removeAndGetNext(node);
	          continue;
	        }

	        if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
	          this.log(
	            "Removing header: ",
	            node.textContent.trim(),
	            this._articleTitle.trim()
	          );
	          shouldRemoveTitleHeader = false;
	          node = this._removeAndGetNext(node);
	          continue;
	        }

	        // Remove unlikely candidates
	        if (stripUnlikelyCandidates) {
	          if (
	            this.REGEXPS.unlikelyCandidates.test(matchString) &&
	            !this.REGEXPS.okMaybeItsACandidate.test(matchString) &&
	            !this._hasAncestorTag(node, "table") &&
	            !this._hasAncestorTag(node, "code") &&
	            node.tagName !== "BODY" &&
	            node.tagName !== "A"
	          ) {
	            this.log("Removing unlikely candidate - " + matchString);
	            node = this._removeAndGetNext(node);
	            continue;
	          }

	          if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
	            this.log(
	              "Removing content with role " +
	                node.getAttribute("role") +
	                " - " +
	                matchString
	            );
	            node = this._removeAndGetNext(node);
	            continue;
	          }
	        }

	        // Remove DIV, SECTION, and HEADER nodes without any content(e.g. text, image, video, or iframe).
	        if (
	          (node.tagName === "DIV" ||
	            node.tagName === "SECTION" ||
	            node.tagName === "HEADER" ||
	            node.tagName === "H1" ||
	            node.tagName === "H2" ||
	            node.tagName === "H3" ||
	            node.tagName === "H4" ||
	            node.tagName === "H5" ||
	            node.tagName === "H6") &&
	          this._isElementWithoutContent(node)
	        ) {
	          node = this._removeAndGetNext(node);
	          continue;
	        }

	        if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) {
	          elementsToScore.push(node);
	        }

	        // Turn all divs that don't have children block level elements into p's
	        if (node.tagName === "DIV") {
	          // Put phrasing content into paragraphs.
	          var p = null;
	          var childNode = node.firstChild;
	          while (childNode) {
	            var nextSibling = childNode.nextSibling;
	            if (this._isPhrasingContent(childNode)) {
	              if (p !== null) {
	                p.appendChild(childNode);
	              } else if (!this._isWhitespace(childNode)) {
	                p = doc.createElement("p");
	                node.replaceChild(p, childNode);
	                p.appendChild(childNode);
	              }
	            } else if (p !== null) {
	              while (p.lastChild && this._isWhitespace(p.lastChild)) {
	                p.lastChild.remove();
	              }
	              p = null;
	            }
	            childNode = nextSibling;
	          }

	          // Sites like http://mobile.slate.com encloses each paragraph with a DIV
	          // element. DIVs with only a P element inside and no text content can be
	          // safely converted into plain P elements to avoid confusing the scoring
	          // algorithm with DIVs with are, in practice, paragraphs.
	          if (
	            this._hasSingleTagInsideElement(node, "P") &&
	            this._getLinkDensity(node) < 0.25
	          ) {
	            var newNode = node.children[0];
	            node.parentNode.replaceChild(newNode, node);
	            node = newNode;
	            elementsToScore.push(node);
	          } else if (!this._hasChildBlockElement(node)) {
	            node = this._setNodeTag(node, "P");
	            elementsToScore.push(node);
	          }
	        }
	        node = this._getNextNode(node);
	      }

	      /**
	       * Loop through all paragraphs, and assign a score to them based on how content-y they look.
	       * Then add their score to their parent node.
	       *
	       * A score is determined by things like number of commas, class names, etc. Maybe eventually link density.
	       **/
	      var candidates = [];
	      this._forEachNode(elementsToScore, function (elementToScore) {
	        if (
	          !elementToScore.parentNode ||
	          typeof elementToScore.parentNode.tagName === "undefined"
	        ) {
	          return;
	        }

	        // If this paragraph is less than 25 characters, don't even count it.
	        var innerText = this._getInnerText(elementToScore);
	        if (innerText.length < 25) {
	          return;
	        }

	        // Exclude nodes with no ancestor.
	        var ancestors = this._getNodeAncestors(elementToScore, 5);
	        if (ancestors.length === 0) {
	          return;
	        }

	        var contentScore = 0;

	        // Add a point for the paragraph itself as a base.
	        contentScore += 1;

	        // Add points for any commas within this paragraph.
	        contentScore += innerText.split(this.REGEXPS.commas).length;

	        // For every 100 characters in this paragraph, add another point. Up to 3 points.
	        contentScore += Math.min(Math.floor(innerText.length / 100), 3);

	        // Initialize and score ancestors.
	        this._forEachNode(ancestors, function (ancestor, level) {
	          if (
	            !ancestor.tagName ||
	            !ancestor.parentNode ||
	            typeof ancestor.parentNode.tagName === "undefined"
	          ) {
	            return;
	          }

	          if (typeof ancestor.readability === "undefined") {
	            this._initializeNode(ancestor);
	            candidates.push(ancestor);
	          }

	          // Node score divider:
	          // - parent:             1 (no division)
	          // - grandparent:        2
	          // - great grandparent+: ancestor level * 3
	          if (level === 0) {
	            var scoreDivider = 1;
	          } else if (level === 1) {
	            scoreDivider = 2;
	          } else {
	            scoreDivider = level * 3;
	          }
	          ancestor.readability.contentScore += contentScore / scoreDivider;
	        });
	      });

	      // After we've calculated scores, loop through all of the possible
	      // candidate nodes we found and find the one with the highest score.
	      var topCandidates = [];
	      for (var c = 0, cl = candidates.length; c < cl; c += 1) {
	        var candidate = candidates[c];

	        // Scale the final candidates score based on link density. Good content
	        // should have a relatively small link density (5% or less) and be mostly
	        // unaffected by this operation.
	        var candidateScore =
	          candidate.readability.contentScore *
	          (1 - this._getLinkDensity(candidate));
	        candidate.readability.contentScore = candidateScore;

	        this.log("Candidate:", candidate, "with score " + candidateScore);

	        for (var t = 0; t < this._nbTopCandidates; t++) {
	          var aTopCandidate = topCandidates[t];

	          if (
	            !aTopCandidate ||
	            candidateScore > aTopCandidate.readability.contentScore
	          ) {
	            topCandidates.splice(t, 0, candidate);
	            if (topCandidates.length > this._nbTopCandidates) {
	              topCandidates.pop();
	            }
	            break;
	          }
	        }
	      }

	      var topCandidate = topCandidates[0] || null;
	      var neededToCreateTopCandidate = false;
	      var parentOfTopCandidate;

	      // If we still have no top candidate, just use the body as a last resort.
	      // We also have to copy the body node so it is something we can modify.
	      if (topCandidate === null || topCandidate.tagName === "BODY") {
	        // Move all of the page's children into topCandidate
	        topCandidate = doc.createElement("DIV");
	        neededToCreateTopCandidate = true;
	        // Move everything (not just elements, also text nodes etc.) into the container
	        // so we even include text directly in the body:
	        while (page.firstChild) {
	          this.log("Moving child out:", page.firstChild);
	          topCandidate.appendChild(page.firstChild);
	        }

	        page.appendChild(topCandidate);

	        this._initializeNode(topCandidate);
	      } else if (topCandidate) {
	        // Find a better top candidate node if it contains (at least three) nodes which belong to `topCandidates` array
	        // and whose scores are quite closed with current `topCandidate` node.
	        var alternativeCandidateAncestors = [];
	        for (var i = 1; i < topCandidates.length; i++) {
	          if (
	            topCandidates[i].readability.contentScore /
	              topCandidate.readability.contentScore >=
	            0.75
	          ) {
	            alternativeCandidateAncestors.push(
	              this._getNodeAncestors(topCandidates[i])
	            );
	          }
	        }
	        var MINIMUM_TOPCANDIDATES = 3;
	        if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
	          parentOfTopCandidate = topCandidate.parentNode;
	          while (parentOfTopCandidate.tagName !== "BODY") {
	            var listsContainingThisAncestor = 0;
	            for (
	              var ancestorIndex = 0;
	              ancestorIndex < alternativeCandidateAncestors.length &&
	              listsContainingThisAncestor < MINIMUM_TOPCANDIDATES;
	              ancestorIndex++
	            ) {
	              listsContainingThisAncestor += Number(
	                alternativeCandidateAncestors[ancestorIndex].includes(
	                  parentOfTopCandidate
	                )
	              );
	            }
	            if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
	              topCandidate = parentOfTopCandidate;
	              break;
	            }
	            parentOfTopCandidate = parentOfTopCandidate.parentNode;
	          }
	        }
	        if (!topCandidate.readability) {
	          this._initializeNode(topCandidate);
	        }

	        // Because of our bonus system, parents of candidates might have scores
	        // themselves. They get half of the node. There won't be nodes with higher
	        // scores than our topCandidate, but if we see the score going *up* in the first
	        // few steps up the tree, that's a decent sign that there might be more content
	        // lurking in other places that we want to unify in. The sibling stuff
	        // below does some of that - but only if we've looked high enough up the DOM
	        // tree.
	        parentOfTopCandidate = topCandidate.parentNode;
	        var lastScore = topCandidate.readability.contentScore;
	        // The scores shouldn't get too low.
	        var scoreThreshold = lastScore / 3;
	        while (parentOfTopCandidate.tagName !== "BODY") {
	          if (!parentOfTopCandidate.readability) {
	            parentOfTopCandidate = parentOfTopCandidate.parentNode;
	            continue;
	          }
	          var parentScore = parentOfTopCandidate.readability.contentScore;
	          if (parentScore < scoreThreshold) {
	            break;
	          }
	          if (parentScore > lastScore) {
	            // Alright! We found a better parent to use.
	            topCandidate = parentOfTopCandidate;
	            break;
	          }
	          lastScore = parentOfTopCandidate.readability.contentScore;
	          parentOfTopCandidate = parentOfTopCandidate.parentNode;
	        }

	        // If the top candidate is the only child, use parent instead. This will help sibling
	        // joining logic when adjacent content is actually located in parent's sibling node.
	        parentOfTopCandidate = topCandidate.parentNode;
	        while (
	          parentOfTopCandidate.tagName != "BODY" &&
	          parentOfTopCandidate.children.length == 1
	        ) {
	          topCandidate = parentOfTopCandidate;
	          parentOfTopCandidate = topCandidate.parentNode;
	        }
	        if (!topCandidate.readability) {
	          this._initializeNode(topCandidate);
	        }
	      }

	      // Now that we have the top candidate, look through its siblings for content
	      // that might also be related. Things like preambles, content split by ads
	      // that we removed, etc.
	      var articleContent = doc.createElement("DIV");
	      if (isPaging) {
	        articleContent.id = "readability-content";
	      }

	      var siblingScoreThreshold = Math.max(
	        10,
	        topCandidate.readability.contentScore * 0.2
	      );
	      // Keep potential top candidate's parent node to try to get text direction of it later.
	      parentOfTopCandidate = topCandidate.parentNode;
	      var siblings = parentOfTopCandidate.children;

	      for (var s = 0, sl = siblings.length; s < sl; s++) {
	        var sibling = siblings[s];
	        var append = false;

	        this.log(
	          "Looking at sibling node:",
	          sibling,
	          sibling.readability
	            ? "with score " + sibling.readability.contentScore
	            : ""
	        );
	        this.log(
	          "Sibling has score",
	          sibling.readability ? sibling.readability.contentScore : "Unknown"
	        );

	        if (sibling === topCandidate) {
	          append = true;
	        } else {
	          var contentBonus = 0;

	          // Give a bonus if sibling nodes and top candidates have the example same classname
	          if (
	            sibling.className === topCandidate.className &&
	            topCandidate.className !== ""
	          ) {
	            contentBonus += topCandidate.readability.contentScore * 0.2;
	          }

	          if (
	            sibling.readability &&
	            sibling.readability.contentScore + contentBonus >=
	              siblingScoreThreshold
	          ) {
	            append = true;
	          } else if (sibling.nodeName === "P") {
	            var linkDensity = this._getLinkDensity(sibling);
	            var nodeContent = this._getInnerText(sibling);
	            var nodeLength = nodeContent.length;

	            if (nodeLength > 80 && linkDensity < 0.25) {
	              append = true;
	            } else if (
	              nodeLength < 80 &&
	              nodeLength > 0 &&
	              linkDensity === 0 &&
	              nodeContent.search(/\.( |$)/) !== -1
	            ) {
	              append = true;
	            }
	          }
	        }

	        if (append) {
	          this.log("Appending node:", sibling);

	          if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
	            // We have a node that isn't a common block level element, like a form or td tag.
	            // Turn it into a div so it doesn't get filtered out later by accident.
	            this.log("Altering sibling:", sibling, "to div.");

	            sibling = this._setNodeTag(sibling, "DIV");
	          }

	          articleContent.appendChild(sibling);
	          // Fetch children again to make it compatible
	          // with DOM parsers without live collection support.
	          siblings = parentOfTopCandidate.children;
	          // siblings is a reference to the children array, and
	          // sibling is removed from the array when we call appendChild().
	          // As a result, we must revisit this index since the nodes
	          // have been shifted.
	          s -= 1;
	          sl -= 1;
	        }
	      }

	      if (this._debug) {
	        this.log("Article content pre-prep: " + articleContent.innerHTML);
	      }
	      // So we have all of the content that we need. Now we clean it up for presentation.
	      this._prepArticle(articleContent);
	      if (this._debug) {
	        this.log("Article content post-prep: " + articleContent.innerHTML);
	      }

	      if (neededToCreateTopCandidate) {
	        // We already created a fake div thing, and there wouldn't have been any siblings left
	        // for the previous loop, so there's no point trying to create a new div, and then
	        // move all the children over. Just assign IDs and class names here. No need to append
	        // because that already happened anyway.
	        topCandidate.id = "readability-page-1";
	        topCandidate.className = "page";
	      } else {
	        var div = doc.createElement("DIV");
	        div.id = "readability-page-1";
	        div.className = "page";
	        while (articleContent.firstChild) {
	          div.appendChild(articleContent.firstChild);
	        }
	        articleContent.appendChild(div);
	      }

	      if (this._debug) {
	        this.log("Article content after paging: " + articleContent.innerHTML);
	      }

	      var parseSuccessful = true;

	      // Now that we've gone through the full algorithm, check to see if
	      // we got any meaningful content. If we didn't, we may need to re-run
	      // grabArticle with different flags set. This gives us a higher likelihood of
	      // finding the content, and the sieve approach gives us a higher likelihood of
	      // finding the -right- content.
	      var textLength = this._getInnerText(articleContent, true).length;
	      if (textLength < this._charThreshold) {
	        parseSuccessful = false;
	        // eslint-disable-next-line no-unsanitized/property
	        page.innerHTML = pageCacheHtml;

	        this._attempts.push({
	          articleContent,
	          textLength,
	        });

	        if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
	          this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
	        } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
	          this._removeFlag(this.FLAG_WEIGHT_CLASSES);
	        } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
	          this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
	        } else {
	          // No luck after removing flags, just return the longest text we found during the different loops
	          this._attempts.sort(function (a, b) {
	            return b.textLength - a.textLength;
	          });

	          // But first check if we actually have something
	          if (!this._attempts[0].textLength) {
	            return null;
	          }

	          articleContent = this._attempts[0].articleContent;
	          parseSuccessful = true;
	        }
	      }

	      if (parseSuccessful) {
	        // Find out text direction from ancestors of final top candidate.
	        var ancestors = [parentOfTopCandidate, topCandidate].concat(
	          this._getNodeAncestors(parentOfTopCandidate)
	        );
	        this._someNode(ancestors, function (ancestor) {
	          if (!ancestor.tagName) {
	            return false;
	          }
	          var articleDir = ancestor.getAttribute("dir");
	          if (articleDir) {
	            this._articleDir = articleDir;
	            return true;
	          }
	          return false;
	        });
	        return articleContent;
	      }
	    }
	  },

	  /**
	   * Converts some of the common HTML entities in string to their corresponding characters.
	   *
	   * @param str {string} - a string to unescape.
	   * @return string without HTML entity.
	   */
	  _unescapeHtmlEntities(str) {
	    if (!str) {
	      return str;
	    }

	    var htmlEscapeMap = this.HTML_ESCAPE_MAP;
	    return str
	      .replace(/&(quot|amp|apos|lt|gt);/g, function (_, tag) {
	        return htmlEscapeMap[tag];
	      })
	      .replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function (_, hex, numStr) {
	        var num = parseInt(hex || numStr, hex ? 16 : 10);

	        // these character references are replaced by a conforming HTML parser
	        if (num == 0 || num > 0x10ffff || (num >= 0xd800 && num <= 0xdfff)) {
	          num = 0xfffd;
	        }

	        return String.fromCodePoint(num);
	      });
	  },

	  /**
	   * Try to extract metadata from JSON-LD object.
	   * For now, only Schema.org objects of type Article or its subtypes are supported.
	   * @return Object with any metadata that could be extracted (possibly none)
	   */
	  _getJSONLD(doc) {
	    var scripts = this._getAllNodesWithTag(doc, ["script"]);

	    var metadata;

	    this._forEachNode(scripts, function (jsonLdElement) {
	      if (
	        !metadata &&
	        jsonLdElement.getAttribute("type") === "application/ld+json"
	      ) {
	        try {
	          // Strip CDATA markers if present
	          var content = jsonLdElement.textContent.replace(
	            /^\s*<!\[CDATA\[|\]\]>\s*$/g,
	            ""
	          );
	          var parsed = JSON.parse(content);

	          if (Array.isArray(parsed)) {
	            parsed = parsed.find(it => {
	              return (
	                it["@type"] &&
	                it["@type"].match(this.REGEXPS.jsonLdArticleTypes)
	              );
	            });
	            if (!parsed) {
	              return;
	            }
	          }

	          var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
	          var matches =
	            (typeof parsed["@context"] === "string" &&
	              parsed["@context"].match(schemaDotOrgRegex)) ||
	            (typeof parsed["@context"] === "object" &&
	              typeof parsed["@context"]["@vocab"] == "string" &&
	              parsed["@context"]["@vocab"].match(schemaDotOrgRegex));

	          if (!matches) {
	            return;
	          }

	          if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
	            parsed = parsed["@graph"].find(it => {
	              return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
	            });
	          }

	          if (
	            !parsed ||
	            !parsed["@type"] ||
	            !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)
	          ) {
	            return;
	          }

	          metadata = {};

	          if (
	            typeof parsed.name === "string" &&
	            typeof parsed.headline === "string" &&
	            parsed.name !== parsed.headline
	          ) {
	            // we have both name and headline element in the JSON-LD. They should both be the same but some websites like aktualne.cz
	            // put their own name into "name" and the article title to "headline" which confuses Readability. So we try to check if either
	            // "name" or "headline" closely matches the html title, and if so, use that one. If not, then we use "name" by default.

	            var title = this._getArticleTitle();
	            var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
	            var headlineMatches =
	              this._textSimilarity(parsed.headline, title) > 0.75;

	            if (headlineMatches && !nameMatches) {
	              metadata.title = parsed.headline;
	            } else {
	              metadata.title = parsed.name;
	            }
	          } else if (typeof parsed.name === "string") {
	            metadata.title = parsed.name.trim();
	          } else if (typeof parsed.headline === "string") {
	            metadata.title = parsed.headline.trim();
	          }
	          if (parsed.author) {
	            if (typeof parsed.author.name === "string") {
	              metadata.byline = parsed.author.name.trim();
	            } else if (
	              Array.isArray(parsed.author) &&
	              parsed.author[0] &&
	              typeof parsed.author[0].name === "string"
	            ) {
	              metadata.byline = parsed.author
	                .filter(function (author) {
	                  return author && typeof author.name === "string";
	                })
	                .map(function (author) {
	                  return author.name.trim();
	                })
	                .join(", ");
	            }
	          }
	          if (typeof parsed.description === "string") {
	            metadata.excerpt = parsed.description.trim();
	          }
	          if (parsed.publisher && typeof parsed.publisher.name === "string") {
	            metadata.siteName = parsed.publisher.name.trim();
	          }
	          if (typeof parsed.datePublished === "string") {
	            metadata.datePublished = parsed.datePublished.trim();
	          }
	        } catch (err) {
	          this.log(err.message);
	        }
	      }
	    });
	    return metadata ? metadata : {};
	  },

	  /**
	   * Attempts to get excerpt and byline metadata for the article.
	   *
	   * @param {Object} jsonld — object containing any metadata that
	   * could be extracted from JSON-LD object.
	   *
	   * @return Object with optional "excerpt" and "byline" properties
	   */
	  _getArticleMetadata(jsonld) {
	    var metadata = {};
	    var values = {};
	    var metaElements = this._doc.getElementsByTagName("meta");

	    // property is a space-separated list of values
	    var propertyPattern =
	      /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;

	    // name is a single value
	    var namePattern =
	      /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;

	    // Find description tags.
	    this._forEachNode(metaElements, function (element) {
	      var elementName = element.getAttribute("name");
	      var elementProperty = element.getAttribute("property");
	      var content = element.getAttribute("content");
	      if (!content) {
	        return;
	      }
	      var matches = null;
	      var name = null;

	      if (elementProperty) {
	        matches = elementProperty.match(propertyPattern);
	        if (matches) {
	          // Convert to lowercase, and remove any whitespace
	          // so we can match below.
	          name = matches[0].toLowerCase().replace(/\s/g, "");
	          // multiple authors
	          values[name] = content.trim();
	        }
	      }
	      if (!matches && elementName && namePattern.test(elementName)) {
	        name = elementName;
	        if (content) {
	          // Convert to lowercase, remove any whitespace, and convert dots
	          // to colons so we can match below.
	          name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
	          values[name] = content.trim();
	        }
	      }
	    });

	    // get title
	    metadata.title =
	      jsonld.title ||
	      values["dc:title"] ||
	      values["dcterm:title"] ||
	      values["og:title"] ||
	      values["weibo:article:title"] ||
	      values["weibo:webpage:title"] ||
	      values.title ||
	      values["twitter:title"] ||
	      values["parsely-title"];

	    if (!metadata.title) {
	      metadata.title = this._getArticleTitle();
	    }

	    const articleAuthor =
	      typeof values["article:author"] === "string" &&
	      !this._isUrl(values["article:author"])
	        ? values["article:author"]
	        : undefined;

	    // get author
	    metadata.byline =
	      jsonld.byline ||
	      values["dc:creator"] ||
	      values["dcterm:creator"] ||
	      values.author ||
	      values["parsely-author"] ||
	      articleAuthor;

	    // get description
	    metadata.excerpt =
	      jsonld.excerpt ||
	      values["dc:description"] ||
	      values["dcterm:description"] ||
	      values["og:description"] ||
	      values["weibo:article:description"] ||
	      values["weibo:webpage:description"] ||
	      values.description ||
	      values["twitter:description"];

	    // get site name
	    metadata.siteName = jsonld.siteName || values["og:site_name"];

	    // get article published time
	    metadata.publishedTime =
	      jsonld.datePublished ||
	      values["article:published_time"] ||
	      values["parsely-pub-date"] ||
	      null;

	    // in many sites the meta value is escaped with HTML entities,
	    // so here we need to unescape it
	    metadata.title = this._unescapeHtmlEntities(metadata.title);
	    metadata.byline = this._unescapeHtmlEntities(metadata.byline);
	    metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
	    metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
	    metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);

	    return metadata;
	  },

	  /**
	   * Check if node is image, or if node contains exactly only one image
	   * whether as a direct child or as its descendants.
	   *
	   * @param Element
	   **/
	  _isSingleImage(node) {
	    while (node) {
	      if (node.tagName === "IMG") {
	        return true;
	      }
	      if (node.children.length !== 1 || node.textContent.trim() !== "") {
	        return false;
	      }
	      node = node.children[0];
	    }
	    return false;
	  },

	  /**
	   * Find all <noscript> that are located after <img> nodes, and which contain only one
	   * <img> element. Replace the first image with the image from inside the <noscript> tag,
	   * and remove the <noscript> tag. This improves the quality of the images we use on
	   * some sites (e.g. Medium).
	   *
	   * @param Element
	   **/
	  _unwrapNoscriptImages(doc) {
	    // Find img without source or attributes that might contains image, and remove it.
	    // This is done to prevent a placeholder img is replaced by img from noscript in next step.
	    var imgs = Array.from(doc.getElementsByTagName("img"));
	    this._forEachNode(imgs, function (img) {
	      for (var i = 0; i < img.attributes.length; i++) {
	        var attr = img.attributes[i];
	        switch (attr.name) {
	          case "src":
	          case "srcset":
	          case "data-src":
	          case "data-srcset":
	            return;
	        }

	        if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
	          return;
	        }
	      }

	      img.remove();
	    });

	    // Next find noscript and try to extract its image
	    var noscripts = Array.from(doc.getElementsByTagName("noscript"));
	    this._forEachNode(noscripts, function (noscript) {
	      // Parse content of noscript and make sure it only contains image
	      if (!this._isSingleImage(noscript)) {
	        return;
	      }
	      var tmp = doc.createElement("div");
	      // We're running in the document context, and using unmodified
	      // document contents, so doing this should be safe.
	      // (Also we heavily discourage people from allowing script to
	      // run at all in this document...)
	      // eslint-disable-next-line no-unsanitized/property
	      tmp.innerHTML = noscript.innerHTML;

	      // If noscript has previous sibling and it only contains image,
	      // replace it with noscript content. However we also keep old
	      // attributes that might contains image.
	      var prevElement = noscript.previousElementSibling;
	      if (prevElement && this._isSingleImage(prevElement)) {
	        var prevImg = prevElement;
	        if (prevImg.tagName !== "IMG") {
	          prevImg = prevElement.getElementsByTagName("img")[0];
	        }

	        var newImg = tmp.getElementsByTagName("img")[0];
	        for (var i = 0; i < prevImg.attributes.length; i++) {
	          var attr = prevImg.attributes[i];
	          if (attr.value === "") {
	            continue;
	          }

	          if (
	            attr.name === "src" ||
	            attr.name === "srcset" ||
	            /\.(jpg|jpeg|png|webp)/i.test(attr.value)
	          ) {
	            if (newImg.getAttribute(attr.name) === attr.value) {
	              continue;
	            }

	            var attrName = attr.name;
	            if (newImg.hasAttribute(attrName)) {
	              attrName = "data-old-" + attrName;
	            }

	            newImg.setAttribute(attrName, attr.value);
	          }
	        }

	        noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
	      }
	    });
	  },

	  /**
	   * Removes script tags from the document.
	   *
	   * @param Element
	   **/
	  _removeScripts(doc) {
	    this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
	  },

	  /**
	   * Check if this node has only whitespace and a single element with given tag
	   * Returns false if the DIV node contains non-empty text nodes
	   * or if it contains no element with given tag or more than 1 element.
	   *
	   * @param Element
	   * @param string tag of child element
	   **/
	  _hasSingleTagInsideElement(element, tag) {
	    // There should be exactly 1 element child with given tag
	    if (element.children.length != 1 || element.children[0].tagName !== tag) {
	      return false;
	    }

	    // And there should be no text nodes with real content
	    return !this._someNode(element.childNodes, function (node) {
	      return (
	        node.nodeType === this.TEXT_NODE &&
	        this.REGEXPS.hasContent.test(node.textContent)
	      );
	    });
	  },

	  _isElementWithoutContent(node) {
	    return (
	      node.nodeType === this.ELEMENT_NODE &&
	      !node.textContent.trim().length &&
	      (!node.children.length ||
	        node.children.length ==
	          node.getElementsByTagName("br").length +
	            node.getElementsByTagName("hr").length)
	    );
	  },

	  /**
	   * Determine whether element has any children block level elements.
	   *
	   * @param Element
	   */
	  _hasChildBlockElement(element) {
	    return this._someNode(element.childNodes, function (node) {
	      return (
	        this.DIV_TO_P_ELEMS.has(node.tagName) ||
	        this._hasChildBlockElement(node)
	      );
	    });
	  },

	  /***
	   * Determine if a node qualifies as phrasing content.
	   * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
	   **/
	  _isPhrasingContent(node) {
	    return (
	      node.nodeType === this.TEXT_NODE ||
	      this.PHRASING_ELEMS.includes(node.tagName) ||
	      ((node.tagName === "A" ||
	        node.tagName === "DEL" ||
	        node.tagName === "INS") &&
	        this._everyNode(node.childNodes, this._isPhrasingContent))
	    );
	  },

	  _isWhitespace(node) {
	    return (
	      (node.nodeType === this.TEXT_NODE &&
	        node.textContent.trim().length === 0) ||
	      (node.nodeType === this.ELEMENT_NODE && node.tagName === "BR")
	    );
	  },

	  /**
	   * Get the inner text of a node - cross browser compatibly.
	   * This also strips out any excess whitespace to be found.
	   *
	   * @param Element
	   * @param Boolean normalizeSpaces (default: true)
	   * @return string
	   **/
	  _getInnerText(e, normalizeSpaces) {
	    normalizeSpaces =
	      typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
	    var textContent = e.textContent.trim();

	    if (normalizeSpaces) {
	      return textContent.replace(this.REGEXPS.normalize, " ");
	    }
	    return textContent;
	  },

	  /**
	   * Get the number of times a string s appears in the node e.
	   *
	   * @param Element
	   * @param string - what to split on. Default is ","
	   * @return number (integer)
	   **/
	  _getCharCount(e, s) {
	    s = s || ",";
	    return this._getInnerText(e).split(s).length - 1;
	  },

	  /**
	   * Remove the style attribute on every e and under.
	   * TODO: Test if getElementsByTagName(*) is faster.
	   *
	   * @param Element
	   * @return void
	   **/
	  _cleanStyles(e) {
	    if (!e || e.tagName.toLowerCase() === "svg") {
	      return;
	    }

	    // Remove `style` and deprecated presentational attributes
	    for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
	      e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
	    }

	    if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
	      e.removeAttribute("width");
	      e.removeAttribute("height");
	    }

	    var cur = e.firstElementChild;
	    while (cur !== null) {
	      this._cleanStyles(cur);
	      cur = cur.nextElementSibling;
	    }
	  },

	  /**
	   * Get the density of links as a percentage of the content
	   * This is the amount of text that is inside a link divided by the total text in the node.
	   *
	   * @param Element
	   * @return number (float)
	   **/
	  _getLinkDensity(element) {
	    var textLength = this._getInnerText(element).length;
	    if (textLength === 0) {
	      return 0;
	    }

	    var linkLength = 0;

	    // XXX implement _reduceNodeList?
	    this._forEachNode(element.getElementsByTagName("a"), function (linkNode) {
	      var href = linkNode.getAttribute("href");
	      var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
	      linkLength += this._getInnerText(linkNode).length * coefficient;
	    });

	    return linkLength / textLength;
	  },

	  /**
	   * Get an elements class/id weight. Uses regular expressions to tell if this
	   * element looks good or bad.
	   *
	   * @param Element
	   * @return number (Integer)
	   **/
	  _getClassWeight(e) {
	    if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
	      return 0;
	    }

	    var weight = 0;

	    // Look for a special classname
	    if (typeof e.className === "string" && e.className !== "") {
	      if (this.REGEXPS.negative.test(e.className)) {
	        weight -= 25;
	      }

	      if (this.REGEXPS.positive.test(e.className)) {
	        weight += 25;
	      }
	    }

	    // Look for a special ID
	    if (typeof e.id === "string" && e.id !== "") {
	      if (this.REGEXPS.negative.test(e.id)) {
	        weight -= 25;
	      }

	      if (this.REGEXPS.positive.test(e.id)) {
	        weight += 25;
	      }
	    }

	    return weight;
	  },

	  /**
	   * Clean a node of all elements of type "tag".
	   * (Unless it's a youtube/vimeo video. People love movies.)
	   *
	   * @param Element
	   * @param string tag to clean
	   * @return void
	   **/
	  _clean(e, tag) {
	    var isEmbed = ["object", "embed", "iframe"].includes(tag);

	    this._removeNodes(this._getAllNodesWithTag(e, [tag]), function (element) {
	      // Allow youtube and vimeo videos through as people usually want to see those.
	      if (isEmbed) {
	        // First, check the elements attributes to see if any of them contain youtube or vimeo
	        for (var i = 0; i < element.attributes.length; i++) {
	          if (this._allowedVideoRegex.test(element.attributes[i].value)) {
	            return false;
	          }
	        }

	        // For embed with <object> tag, check inner HTML as well.
	        if (
	          element.tagName === "object" &&
	          this._allowedVideoRegex.test(element.innerHTML)
	        ) {
	          return false;
	        }
	      }

	      return true;
	    });
	  },

	  /**
	   * Check if a given node has one of its ancestor tag name matching the
	   * provided one.
	   * @param  HTMLElement node
	   * @param  String      tagName
	   * @param  Number      maxDepth
	   * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
	   * @return Boolean
	   */
	  _hasAncestorTag(node, tagName, maxDepth, filterFn) {
	    maxDepth = maxDepth || 3;
	    tagName = tagName.toUpperCase();
	    var depth = 0;
	    while (node.parentNode) {
	      if (maxDepth > 0 && depth > maxDepth) {
	        return false;
	      }
	      if (
	        node.parentNode.tagName === tagName &&
	        (!filterFn || filterFn(node.parentNode))
	      ) {
	        return true;
	      }
	      node = node.parentNode;
	      depth++;
	    }
	    return false;
	  },

	  /**
	   * Return an object indicating how many rows and columns this table has.
	   */
	  _getRowAndColumnCount(table) {
	    var rows = 0;
	    var columns = 0;
	    var trs = table.getElementsByTagName("tr");
	    for (var i = 0; i < trs.length; i++) {
	      var rowspan = trs[i].getAttribute("rowspan") || 0;
	      if (rowspan) {
	        rowspan = parseInt(rowspan, 10);
	      }
	      rows += rowspan || 1;

	      // Now look for column-related info
	      var columnsInThisRow = 0;
	      var cells = trs[i].getElementsByTagName("td");
	      for (var j = 0; j < cells.length; j++) {
	        var colspan = cells[j].getAttribute("colspan") || 0;
	        if (colspan) {
	          colspan = parseInt(colspan, 10);
	        }
	        columnsInThisRow += colspan || 1;
	      }
	      columns = Math.max(columns, columnsInThisRow);
	    }
	    return { rows, columns };
	  },

	  /**
	   * Look for 'data' (as opposed to 'layout') tables, for which we use
	   * similar checks as
	   * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
	   */
	  _markDataTables(root) {
	    var tables = root.getElementsByTagName("table");
	    for (var i = 0; i < tables.length; i++) {
	      var table = tables[i];
	      var role = table.getAttribute("role");
	      if (role == "presentation") {
	        table._readabilityDataTable = false;
	        continue;
	      }
	      var datatable = table.getAttribute("datatable");
	      if (datatable == "0") {
	        table._readabilityDataTable = false;
	        continue;
	      }
	      var summary = table.getAttribute("summary");
	      if (summary) {
	        table._readabilityDataTable = true;
	        continue;
	      }

	      var caption = table.getElementsByTagName("caption")[0];
	      if (caption && caption.childNodes.length) {
	        table._readabilityDataTable = true;
	        continue;
	      }

	      // If the table has a descendant with any of these tags, consider a data table:
	      var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
	      var descendantExists = function (tag) {
	        return !!table.getElementsByTagName(tag)[0];
	      };
	      if (dataTableDescendants.some(descendantExists)) {
	        this.log("Data table because found data-y descendant");
	        table._readabilityDataTable = true;
	        continue;
	      }

	      // Nested tables indicate a layout table:
	      if (table.getElementsByTagName("table")[0]) {
	        table._readabilityDataTable = false;
	        continue;
	      }

	      var sizeInfo = this._getRowAndColumnCount(table);

	      if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
	        // single colum/row tables are commonly used for page layout purposes.
	        table._readabilityDataTable = false;
	        continue;
	      }

	      if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
	        table._readabilityDataTable = true;
	        continue;
	      }
	      // Now just go by size entirely:
	      table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
	    }
	  },

	  /* convert images and figures that have properties like data-src into images that can be loaded without JS */
	  _fixLazyImages(root) {
	    this._forEachNode(
	      this._getAllNodesWithTag(root, ["img", "picture", "figure"]),
	      function (elem) {
	        // In some sites (e.g. Kotaku), they put 1px square image as base64 data uri in the src attribute.
	        // So, here we check if the data uri is too short, just might as well remove it.
	        if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
	          // Make sure it's not SVG, because SVG can have a meaningful image in under 133 bytes.
	          var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
	          if (parts[1] === "image/svg+xml") {
	            return;
	          }

	          // Make sure this element has other attributes which contains image.
	          // If it doesn't, then this src is important and shouldn't be removed.
	          var srcCouldBeRemoved = false;
	          for (var i = 0; i < elem.attributes.length; i++) {
	            var attr = elem.attributes[i];
	            if (attr.name === "src") {
	              continue;
	            }

	            if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
	              srcCouldBeRemoved = true;
	              break;
	            }
	          }

	          // Here we assume if image is less than 100 bytes (or 133 after encoded to base64)
	          // it will be too small, therefore it might be placeholder image.
	          if (srcCouldBeRemoved) {
	            var b64starts = parts[0].length;
	            var b64length = elem.src.length - b64starts;
	            if (b64length < 133) {
	              elem.removeAttribute("src");
	            }
	          }
	        }

	        // also check for "null" to work around https://github.com/jsdom/jsdom/issues/2580
	        if (
	          (elem.src || (elem.srcset && elem.srcset != "null")) &&
	          !elem.className.toLowerCase().includes("lazy")
	        ) {
	          return;
	        }

	        for (var j = 0; j < elem.attributes.length; j++) {
	          attr = elem.attributes[j];
	          if (
	            attr.name === "src" ||
	            attr.name === "srcset" ||
	            attr.name === "alt"
	          ) {
	            continue;
	          }
	          var copyTo = null;
	          if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
	            copyTo = "srcset";
	          } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
	            copyTo = "src";
	          }
	          if (copyTo) {
	            //if this is an img or picture, set the attribute directly
	            if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
	              elem.setAttribute(copyTo, attr.value);
	            } else if (
	              elem.tagName === "FIGURE" &&
	              !this._getAllNodesWithTag(elem, ["img", "picture"]).length
	            ) {
	              //if the item is a <figure> that does not contain an image or picture, create one and place it inside the figure
	              //see the nytimes-3 testcase for an example
	              var img = this._doc.createElement("img");
	              img.setAttribute(copyTo, attr.value);
	              elem.appendChild(img);
	            }
	          }
	        }
	      }
	    );
	  },

	  _getTextDensity(e, tags) {
	    var textLength = this._getInnerText(e, true).length;
	    if (textLength === 0) {
	      return 0;
	    }
	    var childrenLength = 0;
	    var children = this._getAllNodesWithTag(e, tags);
	    this._forEachNode(
	      children,
	      child => (childrenLength += this._getInnerText(child, true).length)
	    );
	    return childrenLength / textLength;
	  },

	  /**
	   * Clean an element of all tags of type "tag" if they look fishy.
	   * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
	   *
	   * @return void
	   **/
	  _cleanConditionally(e, tag) {
	    if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
	      return;
	    }

	    // Gather counts for other typical elements embedded within.
	    // Traverse backwards so we can remove nodes at the same time
	    // without effecting the traversal.
	    //
	    // TODO: Consider taking into account original contentScore here.
	    this._removeNodes(this._getAllNodesWithTag(e, [tag]), function (node) {
	      // First check if this node IS data table, in which case don't remove it.
	      var isDataTable = function (t) {
	        return t._readabilityDataTable;
	      };

	      var isList = tag === "ul" || tag === "ol";
	      if (!isList) {
	        var listLength = 0;
	        var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
	        this._forEachNode(
	          listNodes,
	          list => (listLength += this._getInnerText(list).length)
	        );
	        isList = listLength / this._getInnerText(node).length > 0.9;
	      }

	      if (tag === "table" && isDataTable(node)) {
	        return false;
	      }

	      // Next check if we're inside a data table, in which case don't remove it as well.
	      if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
	        return false;
	      }

	      if (this._hasAncestorTag(node, "code")) {
	        return false;
	      }

	      // keep element if it has a data tables
	      if (
	        [...node.getElementsByTagName("table")].some(
	          tbl => tbl._readabilityDataTable
	        )
	      ) {
	        return false;
	      }

	      var weight = this._getClassWeight(node);

	      this.log("Cleaning Conditionally", node);

	      var contentScore = 0;

	      if (weight + contentScore < 0) {
	        return true;
	      }

	      if (this._getCharCount(node, ",") < 10) {
	        // If there are not very many commas, and the number of
	        // non-paragraph elements is more than paragraphs or other
	        // ominous signs, remove the element.
	        var p = node.getElementsByTagName("p").length;
	        var img = node.getElementsByTagName("img").length;
	        var li = node.getElementsByTagName("li").length - 100;
	        var input = node.getElementsByTagName("input").length;
	        var headingDensity = this._getTextDensity(node, [
	          "h1",
	          "h2",
	          "h3",
	          "h4",
	          "h5",
	          "h6",
	        ]);

	        var embedCount = 0;
	        var embeds = this._getAllNodesWithTag(node, [
	          "object",
	          "embed",
	          "iframe",
	        ]);

	        for (var i = 0; i < embeds.length; i++) {
	          // If this embed has attribute that matches video regex, don't delete it.
	          for (var j = 0; j < embeds[i].attributes.length; j++) {
	            if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
	              return false;
	            }
	          }

	          // For embed with <object> tag, check inner HTML as well.
	          if (
	            embeds[i].tagName === "object" &&
	            this._allowedVideoRegex.test(embeds[i].innerHTML)
	          ) {
	            return false;
	          }

	          embedCount++;
	        }

	        var innerText = this._getInnerText(node);

	        // toss any node whose inner text contains nothing but suspicious words
	        if (
	          this.REGEXPS.adWords.test(innerText) ||
	          this.REGEXPS.loadingWords.test(innerText)
	        ) {
	          return true;
	        }

	        var contentLength = innerText.length;
	        var linkDensity = this._getLinkDensity(node);
	        var textishTags = ["SPAN", "LI", "TD"].concat(
	          Array.from(this.DIV_TO_P_ELEMS)
	        );
	        var textDensity = this._getTextDensity(node, textishTags);
	        var isFigureChild = this._hasAncestorTag(node, "figure");

	        // apply shadiness checks, then check for exceptions
	        const shouldRemoveNode = () => {
	          const errs = [];
	          if (!isFigureChild && img > 1 && p / img < 0.5) {
	            errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
	          }
	          if (!isList && li > p) {
	            errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
	          }
	          if (input > Math.floor(p / 3)) {
	            errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
	          }
	          if (
	            !isList &&
	            !isFigureChild &&
	            headingDensity < 0.9 &&
	            contentLength < 25 &&
	            (img === 0 || img > 2) &&
	            linkDensity > 0
	          ) {
	            errs.push(
	              `Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`
	            );
	          }
	          if (
	            !isList &&
	            weight < 25 &&
	            linkDensity > 0.2 + this._linkDensityModifier
	          ) {
	            errs.push(
	              `Low weight and a little linky. (linkDensity=${linkDensity})`
	            );
	          }
	          if (weight >= 25 && linkDensity > 0.5 + this._linkDensityModifier) {
	            errs.push(
	              `High weight and mostly links. (linkDensity=${linkDensity})`
	            );
	          }
	          if ((embedCount === 1 && contentLength < 75) || embedCount > 1) {
	            errs.push(
	              `Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`
	            );
	          }
	          if (img === 0 && textDensity === 0) {
	            errs.push(
	              `No useful content. (img=${img}, textDensity=${textDensity})`
	            );
	          }

	          if (errs.length) {
	            this.log("Checks failed", errs);
	            return true;
	          }

	          return false;
	        };

	        var haveToRemove = shouldRemoveNode();

	        // Allow simple lists of images to remain in pages
	        if (isList && haveToRemove) {
	          for (var x = 0; x < node.children.length; x++) {
	            let child = node.children[x];
	            // Don't filter in lists with li's that contain more than one child
	            if (child.children.length > 1) {
	              return haveToRemove;
	            }
	          }
	          let li_count = node.getElementsByTagName("li").length;
	          // Only allow the list to remain if every li contains an image
	          if (img == li_count) {
	            return false;
	          }
	        }
	        return haveToRemove;
	      }
	      return false;
	    });
	  },

	  /**
	   * Clean out elements that match the specified conditions
	   *
	   * @param Element
	   * @param Function determines whether a node should be removed
	   * @return void
	   **/
	  _cleanMatchedNodes(e, filter) {
	    var endOfSearchMarkerNode = this._getNextNode(e, true);
	    var next = this._getNextNode(e);
	    while (next && next != endOfSearchMarkerNode) {
	      if (filter.call(this, next, next.className + " " + next.id)) {
	        next = this._removeAndGetNext(next);
	      } else {
	        next = this._getNextNode(next);
	      }
	    }
	  },

	  /**
	   * Clean out spurious headers from an Element.
	   *
	   * @param Element
	   * @return void
	   **/
	  _cleanHeaders(e) {
	    let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
	    this._removeNodes(headingNodes, function (node) {
	      let shouldRemove = this._getClassWeight(node) < 0;
	      if (shouldRemove) {
	        this.log("Removing header with low class weight:", node);
	      }
	      return shouldRemove;
	    });
	  },

	  /**
	   * Check if this node is an H1 or H2 element whose content is mostly
	   * the same as the article title.
	   *
	   * @param Element  the node to check.
	   * @return boolean indicating whether this is a title-like header.
	   */
	  _headerDuplicatesTitle(node) {
	    if (node.tagName != "H1" && node.tagName != "H2") {
	      return false;
	    }
	    var heading = this._getInnerText(node, false);
	    this.log("Evaluating similarity of header:", heading, this._articleTitle);
	    return this._textSimilarity(this._articleTitle, heading) > 0.75;
	  },

	  _flagIsActive(flag) {
	    return (this._flags & flag) > 0;
	  },

	  _removeFlag(flag) {
	    this._flags = this._flags & ~flag;
	  },

	  _isProbablyVisible(node) {
	    // Have to null-check node.style and node.className.includes to deal with SVG and MathML nodes.
	    return (
	      (!node.style || node.style.display != "none") &&
	      (!node.style || node.style.visibility != "hidden") &&
	      !node.hasAttribute("hidden") &&
	      //check for "fallback-image" so that wikimedia math images are displayed
	      (!node.hasAttribute("aria-hidden") ||
	        node.getAttribute("aria-hidden") != "true" ||
	        (node.className &&
	          node.className.includes &&
	          node.className.includes("fallback-image")))
	    );
	  },

	  /**
	   * Runs readability.
	   *
	   * Workflow:
	   *  1. Prep the document by removing script tags, css, etc.
	   *  2. Build readability's DOM tree.
	   *  3. Grab the article content from the current dom tree.
	   *  4. Replace the current DOM tree with the new one.
	   *  5. Read peacefully.
	   *
	   * @return void
	   **/
	  parse() {
	    // Avoid parsing too large documents, as per configuration option
	    if (this._maxElemsToParse > 0) {
	      var numTags = this._doc.getElementsByTagName("*").length;
	      if (numTags > this._maxElemsToParse) {
	        throw new Error(
	          "Aborting parsing document; " + numTags + " elements found"
	        );
	      }
	    }

	    // Unwrap image from noscript
	    this._unwrapNoscriptImages(this._doc);

	    // Extract JSON-LD metadata before removing scripts
	    var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);

	    // Remove script tags from the document.
	    this._removeScripts(this._doc);

	    this._prepDocument();

	    var metadata = this._getArticleMetadata(jsonLd);
	    this._metadata = metadata;
	    this._articleTitle = metadata.title;

	    var articleContent = this._grabArticle();
	    if (!articleContent) {
	      return null;
	    }

	    this.log("Grabbed: " + articleContent.innerHTML);

	    this._postProcessContent(articleContent);

	    // If we haven't found an excerpt in the article's metadata, use the article's
	    // first paragraph as the excerpt. This is used for displaying a preview of
	    // the article's content.
	    if (!metadata.excerpt) {
	      var paragraphs = articleContent.getElementsByTagName("p");
	      if (paragraphs.length) {
	        metadata.excerpt = paragraphs[0].textContent.trim();
	      }
	    }

	    var textContent = articleContent.textContent;
	    return {
	      title: this._articleTitle,
	      byline: metadata.byline || this._articleByline,
	      dir: this._articleDir,
	      lang: this._articleLang,
	      content: this._serializer(articleContent),
	      textContent,
	      length: textContent.length,
	      excerpt: metadata.excerpt,
	      siteName: metadata.siteName || this._articleSiteName,
	      publishedTime: metadata.publishedTime,
	    };
	  },
	};

	{
	  /* eslint-disable-next-line no-redeclare */
	  /* global module */
	  module.exports = Readability;
	} 
} (Readability$1));

var ReadabilityExports = Readability$1.exports;

var ReadabilityReaderable = {exports: {}};

/*
 * Copyright (c) 2010 Arc90 Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

(function (module) {
	/*
	 * This code is heavily based on Arc90's readability.js (1.7.1) script
	 * available at: http://code.google.com/p/arc90labs-readability
	 */

	var REGEXPS = {
	  // NOTE: These two regular expressions are duplicated in
	  // Readability.js. Please keep both copies in sync.
	  unlikelyCandidates:
	    /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
	  okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
	};

	function isNodeVisible(node) {
	  // Have to null-check node.style and node.className.includes to deal with SVG and MathML nodes.
	  return (
	    (!node.style || node.style.display != "none") &&
	    !node.hasAttribute("hidden") &&
	    //check for "fallback-image" so that wikimedia math images are displayed
	    (!node.hasAttribute("aria-hidden") ||
	      node.getAttribute("aria-hidden") != "true" ||
	      (node.className &&
	        node.className.includes &&
	        node.className.includes("fallback-image")))
	  );
	}

	/**
	 * Decides whether or not the document is reader-able without parsing the whole thing.
	 * @param {Object} options Configuration object.
	 * @param {number} [options.minContentLength=140] The minimum node content length used to decide if the document is readerable.
	 * @param {number} [options.minScore=20] The minumum cumulated 'score' used to determine if the document is readerable.
	 * @param {Function} [options.visibilityChecker=isNodeVisible] The function used to determine if a node is visible.
	 * @return {boolean} Whether or not we suspect Readability.parse() will suceeed at returning an article object.
	 */
	function isProbablyReaderable(doc, options = {}) {
	  // For backward compatibility reasons 'options' can either be a configuration object or the function used
	  // to determine if a node is visible.
	  if (typeof options == "function") {
	    options = { visibilityChecker: options };
	  }

	  var defaultOptions = {
	    minScore: 20,
	    minContentLength: 140,
	    visibilityChecker: isNodeVisible,
	  };
	  options = Object.assign(defaultOptions, options);

	  var nodes = doc.querySelectorAll("p, pre, article");

	  // Get <div> nodes which have <br> node(s) and append them into the `nodes` variable.
	  // Some articles' DOM structures might look like
	  // <div>
	  //   Sentences<br>
	  //   <br>
	  //   Sentences<br>
	  // </div>
	  var brNodes = doc.querySelectorAll("div > br");
	  if (brNodes.length) {
	    var set = new Set(nodes);
	    [].forEach.call(brNodes, function (node) {
	      set.add(node.parentNode);
	    });
	    nodes = Array.from(set);
	  }

	  var score = 0;
	  // This is a little cheeky, we use the accumulator 'score' to decide what to return from
	  // this callback:
	  return [].some.call(nodes, function (node) {
	    if (!options.visibilityChecker(node)) {
	      return false;
	    }

	    var matchString = node.className + " " + node.id;
	    if (
	      REGEXPS.unlikelyCandidates.test(matchString) &&
	      !REGEXPS.okMaybeItsACandidate.test(matchString)
	    ) {
	      return false;
	    }

	    if (node.matches("li p")) {
	      return false;
	    }

	    var textContentLength = node.textContent.trim().length;
	    if (textContentLength < options.minContentLength) {
	      return false;
	    }

	    score += Math.sqrt(textContentLength - options.minContentLength);

	    if (score > options.minScore) {
	      return true;
	    }
	    return false;
	  });
	}

	{
	  /* eslint-disable-next-line no-redeclare */
	  /* global module */
	  module.exports = isProbablyReaderable;
	} 
} (ReadabilityReaderable));

var ReadabilityReaderableExports = ReadabilityReaderable.exports;

/* eslint-env node */

var Readability = ReadabilityExports;
var isProbablyReaderable = ReadabilityReaderableExports;

var readability = {
  Readability,
  isProbablyReaderable,
};

/*! @license DOMPurify 3.3.1 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.3.1/LICENSE */

const {
  entries,
  setPrototypeOf,
  isFrozen,
  getPrototypeOf,
  getOwnPropertyDescriptor
} = Object;
let {
  freeze,
  seal,
  create
} = Object; // eslint-disable-line import/no-mutable-exports
let {
  apply,
  construct
} = typeof Reflect !== 'undefined' && Reflect;
if (!freeze) {
  freeze = function freeze(x) {
    return x;
  };
}
if (!seal) {
  seal = function seal(x) {
    return x;
  };
}
if (!apply) {
  apply = function apply(func, thisArg) {
    for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
      args[_key - 2] = arguments[_key];
    }
    return func.apply(thisArg, args);
  };
}
if (!construct) {
  construct = function construct(Func) {
    for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      args[_key2 - 1] = arguments[_key2];
    }
    return new Func(...args);
  };
}
const arrayForEach = unapply(Array.prototype.forEach);
const arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
const arrayPop = unapply(Array.prototype.pop);
const arrayPush = unapply(Array.prototype.push);
const arraySplice = unapply(Array.prototype.splice);
const stringToLowerCase = unapply(String.prototype.toLowerCase);
const stringToString = unapply(String.prototype.toString);
const stringMatch = unapply(String.prototype.match);
const stringReplace = unapply(String.prototype.replace);
const stringIndexOf = unapply(String.prototype.indexOf);
const stringTrim = unapply(String.prototype.trim);
const objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
const regExpTest = unapply(RegExp.prototype.test);
const typeErrorCreate = unconstruct(TypeError);
/**
 * Creates a new function that calls the given function with a specified thisArg and arguments.
 *
 * @param func - The function to be wrapped and called.
 * @returns A new function that calls the given function with a specified thisArg and arguments.
 */
function unapply(func) {
  return function (thisArg) {
    if (thisArg instanceof RegExp) {
      thisArg.lastIndex = 0;
    }
    for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
      args[_key3 - 1] = arguments[_key3];
    }
    return apply(func, thisArg, args);
  };
}
/**
 * Creates a new function that constructs an instance of the given constructor function with the provided arguments.
 *
 * @param func - The constructor function to be wrapped and called.
 * @returns A new function that constructs an instance of the given constructor function with the provided arguments.
 */
function unconstruct(Func) {
  return function () {
    for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      args[_key4] = arguments[_key4];
    }
    return construct(Func, args);
  };
}
/**
 * Add properties to a lookup table
 *
 * @param set - The set to which elements will be added.
 * @param array - The array containing elements to be added to the set.
 * @param transformCaseFunc - An optional function to transform the case of each element before adding to the set.
 * @returns The modified set with added elements.
 */
function addToSet(set, array) {
  let transformCaseFunc = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : stringToLowerCase;
  if (setPrototypeOf) {
    // Make 'in' and truthy checks like Boolean(set.constructor)
    // independent of any properties defined on Object.prototype.
    // Prevent prototype setters from intercepting set as a this value.
    setPrototypeOf(set, null);
  }
  let l = array.length;
  while (l--) {
    let element = array[l];
    if (typeof element === 'string') {
      const lcElement = transformCaseFunc(element);
      if (lcElement !== element) {
        // Config presets (e.g. tags.js, attrs.js) are immutable.
        if (!isFrozen(array)) {
          array[l] = lcElement;
        }
        element = lcElement;
      }
    }
    set[element] = true;
  }
  return set;
}
/**
 * Clean up an array to harden against CSPP
 *
 * @param array - The array to be cleaned.
 * @returns The cleaned version of the array
 */
function cleanArray(array) {
  for (let index = 0; index < array.length; index++) {
    const isPropertyExist = objectHasOwnProperty(array, index);
    if (!isPropertyExist) {
      array[index] = null;
    }
  }
  return array;
}
/**
 * Shallow clone an object
 *
 * @param object - The object to be cloned.
 * @returns A new object that copies the original.
 */
function clone(object) {
  const newObject = create(null);
  for (const [property, value] of entries(object)) {
    const isPropertyExist = objectHasOwnProperty(object, property);
    if (isPropertyExist) {
      if (Array.isArray(value)) {
        newObject[property] = cleanArray(value);
      } else if (value && typeof value === 'object' && value.constructor === Object) {
        newObject[property] = clone(value);
      } else {
        newObject[property] = value;
      }
    }
  }
  return newObject;
}
/**
 * This method automatically checks if the prop is function or getter and behaves accordingly.
 *
 * @param object - The object to look up the getter function in its prototype chain.
 * @param prop - The property name for which to find the getter function.
 * @returns The getter function found in the prototype chain or a fallback function.
 */
function lookupGetter(object, prop) {
  while (object !== null) {
    const desc = getOwnPropertyDescriptor(object, prop);
    if (desc) {
      if (desc.get) {
        return unapply(desc.get);
      }
      if (typeof desc.value === 'function') {
        return unapply(desc.value);
      }
    }
    object = getPrototypeOf(object);
  }
  function fallbackValue() {
    return null;
  }
  return fallbackValue;
}

const html$1 = freeze(['a', 'abbr', 'acronym', 'address', 'area', 'article', 'aside', 'audio', 'b', 'bdi', 'bdo', 'big', 'blink', 'blockquote', 'body', 'br', 'button', 'canvas', 'caption', 'center', 'cite', 'code', 'col', 'colgroup', 'content', 'data', 'datalist', 'dd', 'decorator', 'del', 'details', 'dfn', 'dialog', 'dir', 'div', 'dl', 'dt', 'element', 'em', 'fieldset', 'figcaption', 'figure', 'font', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'head', 'header', 'hgroup', 'hr', 'html', 'i', 'img', 'input', 'ins', 'kbd', 'label', 'legend', 'li', 'main', 'map', 'mark', 'marquee', 'menu', 'menuitem', 'meter', 'nav', 'nobr', 'ol', 'optgroup', 'option', 'output', 'p', 'picture', 'pre', 'progress', 'q', 'rp', 'rt', 'ruby', 's', 'samp', 'search', 'section', 'select', 'shadow', 'slot', 'small', 'source', 'spacer', 'span', 'strike', 'strong', 'style', 'sub', 'summary', 'sup', 'table', 'tbody', 'td', 'template', 'textarea', 'tfoot', 'th', 'thead', 'time', 'tr', 'track', 'tt', 'u', 'ul', 'var', 'video', 'wbr']);
const svg$1 = freeze(['svg', 'a', 'altglyph', 'altglyphdef', 'altglyphitem', 'animatecolor', 'animatemotion', 'animatetransform', 'circle', 'clippath', 'defs', 'desc', 'ellipse', 'enterkeyhint', 'exportparts', 'filter', 'font', 'g', 'glyph', 'glyphref', 'hkern', 'image', 'inputmode', 'line', 'lineargradient', 'marker', 'mask', 'metadata', 'mpath', 'part', 'path', 'pattern', 'polygon', 'polyline', 'radialgradient', 'rect', 'stop', 'style', 'switch', 'symbol', 'text', 'textpath', 'title', 'tref', 'tspan', 'view', 'vkern']);
const svgFilters = freeze(['feBlend', 'feColorMatrix', 'feComponentTransfer', 'feComposite', 'feConvolveMatrix', 'feDiffuseLighting', 'feDisplacementMap', 'feDistantLight', 'feDropShadow', 'feFlood', 'feFuncA', 'feFuncB', 'feFuncG', 'feFuncR', 'feGaussianBlur', 'feImage', 'feMerge', 'feMergeNode', 'feMorphology', 'feOffset', 'fePointLight', 'feSpecularLighting', 'feSpotLight', 'feTile', 'feTurbulence']);
// List of SVG elements that are disallowed by default.
// We still need to know them so that we can do namespace
// checks properly in case one wants to add them to
// allow-list.
const svgDisallowed = freeze(['animate', 'color-profile', 'cursor', 'discard', 'font-face', 'font-face-format', 'font-face-name', 'font-face-src', 'font-face-uri', 'foreignobject', 'hatch', 'hatchpath', 'mesh', 'meshgradient', 'meshpatch', 'meshrow', 'missing-glyph', 'script', 'set', 'solidcolor', 'unknown', 'use']);
const mathMl$1 = freeze(['math', 'menclose', 'merror', 'mfenced', 'mfrac', 'mglyph', 'mi', 'mlabeledtr', 'mmultiscripts', 'mn', 'mo', 'mover', 'mpadded', 'mphantom', 'mroot', 'mrow', 'ms', 'mspace', 'msqrt', 'mstyle', 'msub', 'msup', 'msubsup', 'mtable', 'mtd', 'mtext', 'mtr', 'munder', 'munderover', 'mprescripts']);
// Similarly to SVG, we want to know all MathML elements,
// even those that we disallow by default.
const mathMlDisallowed = freeze(['maction', 'maligngroup', 'malignmark', 'mlongdiv', 'mscarries', 'mscarry', 'msgroup', 'mstack', 'msline', 'msrow', 'semantics', 'annotation', 'annotation-xml', 'mprescripts', 'none']);
const text = freeze(['#text']);

const html = freeze(['accept', 'action', 'align', 'alt', 'autocapitalize', 'autocomplete', 'autopictureinpicture', 'autoplay', 'background', 'bgcolor', 'border', 'capture', 'cellpadding', 'cellspacing', 'checked', 'cite', 'class', 'clear', 'color', 'cols', 'colspan', 'controls', 'controlslist', 'coords', 'crossorigin', 'datetime', 'decoding', 'default', 'dir', 'disabled', 'disablepictureinpicture', 'disableremoteplayback', 'download', 'draggable', 'enctype', 'enterkeyhint', 'exportparts', 'face', 'for', 'headers', 'height', 'hidden', 'high', 'href', 'hreflang', 'id', 'inert', 'inputmode', 'integrity', 'ismap', 'kind', 'label', 'lang', 'list', 'loading', 'loop', 'low', 'max', 'maxlength', 'media', 'method', 'min', 'minlength', 'multiple', 'muted', 'name', 'nonce', 'noshade', 'novalidate', 'nowrap', 'open', 'optimum', 'part', 'pattern', 'placeholder', 'playsinline', 'popover', 'popovertarget', 'popovertargetaction', 'poster', 'preload', 'pubdate', 'radiogroup', 'readonly', 'rel', 'required', 'rev', 'reversed', 'role', 'rows', 'rowspan', 'spellcheck', 'scope', 'selected', 'shape', 'size', 'sizes', 'slot', 'span', 'srclang', 'start', 'src', 'srcset', 'step', 'style', 'summary', 'tabindex', 'title', 'translate', 'type', 'usemap', 'valign', 'value', 'width', 'wrap', 'xmlns', 'slot']);
const svg = freeze(['accent-height', 'accumulate', 'additive', 'alignment-baseline', 'amplitude', 'ascent', 'attributename', 'attributetype', 'azimuth', 'basefrequency', 'baseline-shift', 'begin', 'bias', 'by', 'class', 'clip', 'clippathunits', 'clip-path', 'clip-rule', 'color', 'color-interpolation', 'color-interpolation-filters', 'color-profile', 'color-rendering', 'cx', 'cy', 'd', 'dx', 'dy', 'diffuseconstant', 'direction', 'display', 'divisor', 'dur', 'edgemode', 'elevation', 'end', 'exponent', 'fill', 'fill-opacity', 'fill-rule', 'filter', 'filterunits', 'flood-color', 'flood-opacity', 'font-family', 'font-size', 'font-size-adjust', 'font-stretch', 'font-style', 'font-variant', 'font-weight', 'fx', 'fy', 'g1', 'g2', 'glyph-name', 'glyphref', 'gradientunits', 'gradienttransform', 'height', 'href', 'id', 'image-rendering', 'in', 'in2', 'intercept', 'k', 'k1', 'k2', 'k3', 'k4', 'kerning', 'keypoints', 'keysplines', 'keytimes', 'lang', 'lengthadjust', 'letter-spacing', 'kernelmatrix', 'kernelunitlength', 'lighting-color', 'local', 'marker-end', 'marker-mid', 'marker-start', 'markerheight', 'markerunits', 'markerwidth', 'maskcontentunits', 'maskunits', 'max', 'mask', 'mask-type', 'media', 'method', 'mode', 'min', 'name', 'numoctaves', 'offset', 'operator', 'opacity', 'order', 'orient', 'orientation', 'origin', 'overflow', 'paint-order', 'path', 'pathlength', 'patterncontentunits', 'patterntransform', 'patternunits', 'points', 'preservealpha', 'preserveaspectratio', 'primitiveunits', 'r', 'rx', 'ry', 'radius', 'refx', 'refy', 'repeatcount', 'repeatdur', 'restart', 'result', 'rotate', 'scale', 'seed', 'shape-rendering', 'slope', 'specularconstant', 'specularexponent', 'spreadmethod', 'startoffset', 'stddeviation', 'stitchtiles', 'stop-color', 'stop-opacity', 'stroke-dasharray', 'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'stroke-opacity', 'stroke', 'stroke-width', 'style', 'surfacescale', 'systemlanguage', 'tabindex', 'tablevalues', 'targetx', 'targety', 'transform', 'transform-origin', 'text-anchor', 'text-decoration', 'text-rendering', 'textlength', 'type', 'u1', 'u2', 'unicode', 'values', 'viewbox', 'visibility', 'version', 'vert-adv-y', 'vert-origin-x', 'vert-origin-y', 'width', 'word-spacing', 'wrap', 'writing-mode', 'xchannelselector', 'ychannelselector', 'x', 'x1', 'x2', 'xmlns', 'y', 'y1', 'y2', 'z', 'zoomandpan']);
const mathMl = freeze(['accent', 'accentunder', 'align', 'bevelled', 'close', 'columnsalign', 'columnlines', 'columnspan', 'denomalign', 'depth', 'dir', 'display', 'displaystyle', 'encoding', 'fence', 'frame', 'height', 'href', 'id', 'largeop', 'length', 'linethickness', 'lspace', 'lquote', 'mathbackground', 'mathcolor', 'mathsize', 'mathvariant', 'maxsize', 'minsize', 'movablelimits', 'notation', 'numalign', 'open', 'rowalign', 'rowlines', 'rowspacing', 'rowspan', 'rspace', 'rquote', 'scriptlevel', 'scriptminsize', 'scriptsizemultiplier', 'selection', 'separator', 'separators', 'stretchy', 'subscriptshift', 'supscriptshift', 'symmetric', 'voffset', 'width', 'xmlns']);
const xml = freeze(['xlink:href', 'xml:id', 'xlink:title', 'xml:space', 'xmlns:xlink']);

// eslint-disable-next-line unicorn/better-regex
const MUSTACHE_EXPR = seal(/\{\{[\w\W]*|[\w\W]*\}\}/gm); // Specify template detection regex for SAFE_FOR_TEMPLATES mode
const ERB_EXPR = seal(/<%[\w\W]*|[\w\W]*%>/gm);
const TMPLIT_EXPR = seal(/\$\{[\w\W]*/gm); // eslint-disable-line unicorn/better-regex
const DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/); // eslint-disable-line no-useless-escape
const ARIA_ATTR = seal(/^aria-[\-\w]+$/); // eslint-disable-line no-useless-escape
const IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i // eslint-disable-line no-useless-escape
);
const IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
const ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g // eslint-disable-line no-control-regex
);
const DOCTYPE_NAME = seal(/^html$/i);
const CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);

var EXPRESSIONS = /*#__PURE__*/Object.freeze({
  __proto__: null,
  ARIA_ATTR: ARIA_ATTR,
  ATTR_WHITESPACE: ATTR_WHITESPACE,
  CUSTOM_ELEMENT: CUSTOM_ELEMENT,
  DATA_ATTR: DATA_ATTR,
  DOCTYPE_NAME: DOCTYPE_NAME,
  ERB_EXPR: ERB_EXPR,
  IS_ALLOWED_URI: IS_ALLOWED_URI,
  IS_SCRIPT_OR_DATA: IS_SCRIPT_OR_DATA,
  MUSTACHE_EXPR: MUSTACHE_EXPR,
  TMPLIT_EXPR: TMPLIT_EXPR
});

/* eslint-disable @typescript-eslint/indent */
// https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
const NODE_TYPE = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9};
const getGlobal = function getGlobal() {
  return typeof window === 'undefined' ? null : window;
};
/**
 * Creates a no-op policy for internal use only.
 * Don't export this function outside this module!
 * @param trustedTypes The policy factory.
 * @param purifyHostElement The Script element used to load DOMPurify (to determine policy name suffix).
 * @return The policy created (or null, if Trusted Types
 * are not supported or creating the policy failed).
 */
const _createTrustedTypesPolicy = function _createTrustedTypesPolicy(trustedTypes, purifyHostElement) {
  if (typeof trustedTypes !== 'object' || typeof trustedTypes.createPolicy !== 'function') {
    return null;
  }
  // Allow the callers to control the unique policy name
  // by adding a data-tt-policy-suffix to the script element with the DOMPurify.
  // Policy creation with duplicate names throws in Trusted Types.
  let suffix = null;
  const ATTR_NAME = 'data-tt-policy-suffix';
  if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) {
    suffix = purifyHostElement.getAttribute(ATTR_NAME);
  }
  const policyName = 'dompurify' + (suffix ? '#' + suffix : '');
  try {
    return trustedTypes.createPolicy(policyName, {
      createHTML(html) {
        return html;
      },
      createScriptURL(scriptUrl) {
        return scriptUrl;
      }
    });
  } catch (_) {
    // Policy creation failed (most likely another DOMPurify script has
    // already run). Skip creating the policy, as this will only cause errors
    // if TT are enforced.
    console.warn('TrustedTypes policy ' + policyName + ' could not be created.');
    return null;
  }
};
const _createHooksMap = function _createHooksMap() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function createDOMPurify() {
  let window = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : getGlobal();
  const DOMPurify = root => createDOMPurify(root);
  DOMPurify.version = '3.3.1';
  DOMPurify.removed = [];
  if (!window || !window.document || window.document.nodeType !== NODE_TYPE.document || !window.Element) {
    // Not running in a browser, provide a factory function
    // so that you can pass your own Window
    DOMPurify.isSupported = false;
    return DOMPurify;
  }
  let {
    document
  } = window;
  const originalDocument = document;
  const currentScript = originalDocument.currentScript;
  const {
    DocumentFragment,
    HTMLTemplateElement,
    Node,
    Element,
    NodeFilter,
    NamedNodeMap = window.NamedNodeMap || window.MozNamedAttrMap,
    HTMLFormElement,
    DOMParser,
    trustedTypes
  } = window;
  const ElementPrototype = Element.prototype;
  const cloneNode = lookupGetter(ElementPrototype, 'cloneNode');
  const remove = lookupGetter(ElementPrototype, 'remove');
  const getNextSibling = lookupGetter(ElementPrototype, 'nextSibling');
  const getChildNodes = lookupGetter(ElementPrototype, 'childNodes');
  const getParentNode = lookupGetter(ElementPrototype, 'parentNode');
  // As per issue #47, the web-components registry is inherited by a
  // new document created via createHTMLDocument. As per the spec
  // (http://w3c.github.io/webcomponents/spec/custom/#creating-and-passing-registries)
  // a new empty registry is used when creating a template contents owner
  // document, so we use that as our parent document to ensure nothing
  // is inherited.
  if (typeof HTMLTemplateElement === 'function') {
    const template = document.createElement('template');
    if (template.content && template.content.ownerDocument) {
      document = template.content.ownerDocument;
    }
  }
  let trustedTypesPolicy;
  let emptyHTML = '';
  const {
    implementation,
    createNodeIterator,
    createDocumentFragment,
    getElementsByTagName
  } = document;
  const {
    importNode
  } = originalDocument;
  let hooks = _createHooksMap();
  /**
   * Expose whether this browser supports running the full DOMPurify.
   */
  DOMPurify.isSupported = typeof entries === 'function' && typeof getParentNode === 'function' && implementation && implementation.createHTMLDocument !== undefined;
  const {
    MUSTACHE_EXPR,
    ERB_EXPR,
    TMPLIT_EXPR,
    DATA_ATTR,
    ARIA_ATTR,
    IS_SCRIPT_OR_DATA,
    ATTR_WHITESPACE,
    CUSTOM_ELEMENT
  } = EXPRESSIONS;
  let {
    IS_ALLOWED_URI: IS_ALLOWED_URI$1
  } = EXPRESSIONS;
  /**
   * We consider the elements and attributes below to be safe. Ideally
   * don't add any new ones but feel free to remove unwanted ones.
   */
  /* allowed element names */
  let ALLOWED_TAGS = null;
  const DEFAULT_ALLOWED_TAGS = addToSet({}, [...html$1, ...svg$1, ...svgFilters, ...mathMl$1, ...text]);
  /* Allowed attribute names */
  let ALLOWED_ATTR = null;
  const DEFAULT_ALLOWED_ATTR = addToSet({}, [...html, ...svg, ...mathMl, ...xml]);
  /*
   * Configure how DOMPurify should handle custom elements and their attributes as well as customized built-in elements.
   * @property {RegExp|Function|null} tagNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any custom elements)
   * @property {RegExp|Function|null} attributeNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any attributes not on the allow list)
   * @property {boolean} allowCustomizedBuiltInElements allow custom elements derived from built-ins if they pass CUSTOM_ELEMENT_HANDLING.tagNameCheck. Default: `false`.
   */
  let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
    tagNameCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    attributeNameCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: false
    }
  }));
  /* Explicitly forbidden tags (overrides ALLOWED_TAGS/ADD_TAGS) */
  let FORBID_TAGS = null;
  /* Explicitly forbidden attributes (overrides ALLOWED_ATTR/ADD_ATTR) */
  let FORBID_ATTR = null;
  /* Config object to store ADD_TAGS/ADD_ATTR functions (when used as functions) */
  const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
    tagCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    attributeCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    }
  }));
  /* Decide if ARIA attributes are okay */
  let ALLOW_ARIA_ATTR = true;
  /* Decide if custom data attributes are okay */
  let ALLOW_DATA_ATTR = true;
  /* Decide if unknown protocols are okay */
  let ALLOW_UNKNOWN_PROTOCOLS = false;
  /* Decide if self-closing tags in attributes are allowed.
   * Usually removed due to a mXSS issue in jQuery 3.0 */
  let ALLOW_SELF_CLOSE_IN_ATTR = true;
  /* Output should be safe for common template engines.
   * This means, DOMPurify removes data attributes, mustaches and ERB
   */
  let SAFE_FOR_TEMPLATES = false;
  /* Output should be safe even for XML used within HTML and alike.
   * This means, DOMPurify removes comments when containing risky content.
   */
  let SAFE_FOR_XML = true;
  /* Decide if document with <html>... should be returned */
  let WHOLE_DOCUMENT = false;
  /* Track whether config is already set on this instance of DOMPurify. */
  let SET_CONFIG = false;
  /* Decide if all elements (e.g. style, script) must be children of
   * document.body. By default, browsers might move them to document.head */
  let FORCE_BODY = false;
  /* Decide if a DOM `HTMLBodyElement` should be returned, instead of a html
   * string (or a TrustedHTML object if Trusted Types are supported).
   * If `WHOLE_DOCUMENT` is enabled a `HTMLHtmlElement` will be returned instead
   */
  let RETURN_DOM = false;
  /* Decide if a DOM `DocumentFragment` should be returned, instead of a html
   * string  (or a TrustedHTML object if Trusted Types are supported) */
  let RETURN_DOM_FRAGMENT = false;
  /* Try to return a Trusted Type object instead of a string, return a string in
   * case Trusted Types are not supported  */
  let RETURN_TRUSTED_TYPE = false;
  /* Output should be free from DOM clobbering attacks?
   * This sanitizes markups named with colliding, clobberable built-in DOM APIs.
   */
  let SANITIZE_DOM = true;
  /* Achieve full DOM Clobbering protection by isolating the namespace of named
   * properties and JS variables, mitigating attacks that abuse the HTML/DOM spec rules.
   *
   * HTML/DOM spec rules that enable DOM Clobbering:
   *   - Named Access on Window (§7.3.3)
   *   - DOM Tree Accessors (§3.1.5)
   *   - Form Element Parent-Child Relations (§4.10.3)
   *   - Iframe srcdoc / Nested WindowProxies (§4.8.5)
   *   - HTMLCollection (§4.2.10.2)
   *
   * Namespace isolation is implemented by prefixing `id` and `name` attributes
   * with a constant string, i.e., `user-content-`
   */
  let SANITIZE_NAMED_PROPS = false;
  const SANITIZE_NAMED_PROPS_PREFIX = 'user-content-';
  /* Keep element content when removing element? */
  let KEEP_CONTENT = true;
  /* If a `Node` is passed to sanitize(), then performs sanitization in-place instead
   * of importing it into a new Document and returning a sanitized copy */
  let IN_PLACE = false;
  /* Allow usage of profiles like html, svg and mathMl */
  let USE_PROFILES = {};
  /* Tags to ignore content of when KEEP_CONTENT is true */
  let FORBID_CONTENTS = null;
  const DEFAULT_FORBID_CONTENTS = addToSet({}, ['annotation-xml', 'audio', 'colgroup', 'desc', 'foreignobject', 'head', 'iframe', 'math', 'mi', 'mn', 'mo', 'ms', 'mtext', 'noembed', 'noframes', 'noscript', 'plaintext', 'script', 'style', 'svg', 'template', 'thead', 'title', 'video', 'xmp']);
  /* Tags that are safe for data: URIs */
  let DATA_URI_TAGS = null;
  const DEFAULT_DATA_URI_TAGS = addToSet({}, ['audio', 'video', 'img', 'source', 'image', 'track']);
  /* Attributes safe for values like "javascript:" */
  let URI_SAFE_ATTRIBUTES = null;
  const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, ['alt', 'class', 'for', 'id', 'label', 'name', 'pattern', 'placeholder', 'role', 'summary', 'title', 'value', 'style', 'xmlns']);
  const MATHML_NAMESPACE = 'http://www.w3.org/1998/Math/MathML';
  const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
  const HTML_NAMESPACE = 'http://www.w3.org/1999/xhtml';
  /* Document namespace */
  let NAMESPACE = HTML_NAMESPACE;
  let IS_EMPTY_INPUT = false;
  /* Allowed XHTML+XML namespaces */
  let ALLOWED_NAMESPACES = null;
  const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [MATHML_NAMESPACE, SVG_NAMESPACE, HTML_NAMESPACE], stringToString);
  let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, ['mi', 'mo', 'mn', 'ms', 'mtext']);
  let HTML_INTEGRATION_POINTS = addToSet({}, ['annotation-xml']);
  // Certain elements are allowed in both SVG and HTML
  // namespace. We need to specify them explicitly
  // so that they don't get erroneously deleted from
  // HTML namespace.
  const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, ['title', 'style', 'font', 'a', 'script']);
  /* Parsing of strict XHTML documents */
  let PARSER_MEDIA_TYPE = null;
  const SUPPORTED_PARSER_MEDIA_TYPES = ['application/xhtml+xml', 'text/html'];
  const DEFAULT_PARSER_MEDIA_TYPE = 'text/html';
  let transformCaseFunc = null;
  /* Keep a reference to config to pass to hooks */
  let CONFIG = null;
  /* Ideally, do not touch anything below this line */
  /* ______________________________________________ */
  const formElement = document.createElement('form');
  const isRegexOrFunction = function isRegexOrFunction(testValue) {
    return testValue instanceof RegExp || testValue instanceof Function;
  };
  /**
   * _parseConfig
   *
   * @param cfg optional config literal
   */
  // eslint-disable-next-line complexity
  const _parseConfig = function _parseConfig() {
    let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    if (CONFIG && CONFIG === cfg) {
      return;
    }
    /* Shield configuration object from tampering */
    if (!cfg || typeof cfg !== 'object') {
      cfg = {};
    }
    /* Shield configuration object from prototype pollution */
    cfg = clone(cfg);
    PARSER_MEDIA_TYPE =
    // eslint-disable-next-line unicorn/prefer-includes
    SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
    // HTML tags and attributes are not case-sensitive, converting to lowercase. Keeping XHTML as is.
    transformCaseFunc = PARSER_MEDIA_TYPE === 'application/xhtml+xml' ? stringToString : stringToLowerCase;
    /* Set configuration parameters */
    ALLOWED_TAGS = objectHasOwnProperty(cfg, 'ALLOWED_TAGS') ? addToSet({}, cfg.ALLOWED_TAGS, transformCaseFunc) : DEFAULT_ALLOWED_TAGS;
    ALLOWED_ATTR = objectHasOwnProperty(cfg, 'ALLOWED_ATTR') ? addToSet({}, cfg.ALLOWED_ATTR, transformCaseFunc) : DEFAULT_ALLOWED_ATTR;
    ALLOWED_NAMESPACES = objectHasOwnProperty(cfg, 'ALLOWED_NAMESPACES') ? addToSet({}, cfg.ALLOWED_NAMESPACES, stringToString) : DEFAULT_ALLOWED_NAMESPACES;
    URI_SAFE_ATTRIBUTES = objectHasOwnProperty(cfg, 'ADD_URI_SAFE_ATTR') ? addToSet(clone(DEFAULT_URI_SAFE_ATTRIBUTES), cfg.ADD_URI_SAFE_ATTR, transformCaseFunc) : DEFAULT_URI_SAFE_ATTRIBUTES;
    DATA_URI_TAGS = objectHasOwnProperty(cfg, 'ADD_DATA_URI_TAGS') ? addToSet(clone(DEFAULT_DATA_URI_TAGS), cfg.ADD_DATA_URI_TAGS, transformCaseFunc) : DEFAULT_DATA_URI_TAGS;
    FORBID_CONTENTS = objectHasOwnProperty(cfg, 'FORBID_CONTENTS') ? addToSet({}, cfg.FORBID_CONTENTS, transformCaseFunc) : DEFAULT_FORBID_CONTENTS;
    FORBID_TAGS = objectHasOwnProperty(cfg, 'FORBID_TAGS') ? addToSet({}, cfg.FORBID_TAGS, transformCaseFunc) : clone({});
    FORBID_ATTR = objectHasOwnProperty(cfg, 'FORBID_ATTR') ? addToSet({}, cfg.FORBID_ATTR, transformCaseFunc) : clone({});
    USE_PROFILES = objectHasOwnProperty(cfg, 'USE_PROFILES') ? cfg.USE_PROFILES : false;
    ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false; // Default true
    ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false; // Default true
    ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false; // Default false
    ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false; // Default true
    SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false; // Default false
    SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false; // Default true
    WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false; // Default false
    RETURN_DOM = cfg.RETURN_DOM || false; // Default false
    RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false; // Default false
    RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false; // Default false
    FORCE_BODY = cfg.FORCE_BODY || false; // Default false
    SANITIZE_DOM = cfg.SANITIZE_DOM !== false; // Default true
    SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false; // Default false
    KEEP_CONTENT = cfg.KEEP_CONTENT !== false; // Default true
    IN_PLACE = cfg.IN_PLACE || false; // Default false
    IS_ALLOWED_URI$1 = cfg.ALLOWED_URI_REGEXP || IS_ALLOWED_URI;
    NAMESPACE = cfg.NAMESPACE || HTML_NAMESPACE;
    MATHML_TEXT_INTEGRATION_POINTS = cfg.MATHML_TEXT_INTEGRATION_POINTS || MATHML_TEXT_INTEGRATION_POINTS;
    HTML_INTEGRATION_POINTS = cfg.HTML_INTEGRATION_POINTS || HTML_INTEGRATION_POINTS;
    CUSTOM_ELEMENT_HANDLING = cfg.CUSTOM_ELEMENT_HANDLING || {};
    if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck)) {
      CUSTOM_ELEMENT_HANDLING.tagNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck;
    }
    if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)) {
      CUSTOM_ELEMENT_HANDLING.attributeNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck;
    }
    if (cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements === 'boolean') {
      CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements;
    }
    if (SAFE_FOR_TEMPLATES) {
      ALLOW_DATA_ATTR = false;
    }
    if (RETURN_DOM_FRAGMENT) {
      RETURN_DOM = true;
    }
    /* Parse profile info */
    if (USE_PROFILES) {
      ALLOWED_TAGS = addToSet({}, text);
      ALLOWED_ATTR = [];
      if (USE_PROFILES.html === true) {
        addToSet(ALLOWED_TAGS, html$1);
        addToSet(ALLOWED_ATTR, html);
      }
      if (USE_PROFILES.svg === true) {
        addToSet(ALLOWED_TAGS, svg$1);
        addToSet(ALLOWED_ATTR, svg);
        addToSet(ALLOWED_ATTR, xml);
      }
      if (USE_PROFILES.svgFilters === true) {
        addToSet(ALLOWED_TAGS, svgFilters);
        addToSet(ALLOWED_ATTR, svg);
        addToSet(ALLOWED_ATTR, xml);
      }
      if (USE_PROFILES.mathMl === true) {
        addToSet(ALLOWED_TAGS, mathMl$1);
        addToSet(ALLOWED_ATTR, mathMl);
        addToSet(ALLOWED_ATTR, xml);
      }
    }
    /* Merge configuration parameters */
    if (cfg.ADD_TAGS) {
      if (typeof cfg.ADD_TAGS === 'function') {
        EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
      } else {
        if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) {
          ALLOWED_TAGS = clone(ALLOWED_TAGS);
        }
        addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
      }
    }
    if (cfg.ADD_ATTR) {
      if (typeof cfg.ADD_ATTR === 'function') {
        EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
      } else {
        if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) {
          ALLOWED_ATTR = clone(ALLOWED_ATTR);
        }
        addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
      }
    }
    if (cfg.ADD_URI_SAFE_ATTR) {
      addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
    }
    if (cfg.FORBID_CONTENTS) {
      if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
        FORBID_CONTENTS = clone(FORBID_CONTENTS);
      }
      addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
    }
    if (cfg.ADD_FORBID_CONTENTS) {
      if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
        FORBID_CONTENTS = clone(FORBID_CONTENTS);
      }
      addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
    }
    /* Add #text in case KEEP_CONTENT is set to true */
    if (KEEP_CONTENT) {
      ALLOWED_TAGS['#text'] = true;
    }
    /* Add html, head and body to ALLOWED_TAGS in case WHOLE_DOCUMENT is true */
    if (WHOLE_DOCUMENT) {
      addToSet(ALLOWED_TAGS, ['html', 'head', 'body']);
    }
    /* Add tbody to ALLOWED_TAGS in case tables are permitted, see #286, #365 */
    if (ALLOWED_TAGS.table) {
      addToSet(ALLOWED_TAGS, ['tbody']);
      delete FORBID_TAGS.tbody;
    }
    if (cfg.TRUSTED_TYPES_POLICY) {
      if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== 'function') {
        throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
      }
      if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== 'function') {
        throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
      }
      // Overwrite existing TrustedTypes policy.
      trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
      // Sign local variables required by `sanitize`.
      emptyHTML = trustedTypesPolicy.createHTML('');
    } else {
      // Uninitialized policy, attempt to initialize the internal dompurify policy.
      if (trustedTypesPolicy === undefined) {
        trustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
      }
      // If creating the internal policy succeeded sign internal variables.
      if (trustedTypesPolicy !== null && typeof emptyHTML === 'string') {
        emptyHTML = trustedTypesPolicy.createHTML('');
      }
    }
    // Prevent further manipulation of configuration.
    // Not available in IE8, Safari 5, etc.
    if (freeze) {
      freeze(cfg);
    }
    CONFIG = cfg;
  };
  /* Keep track of all possible SVG and MathML tags
   * so that we can perform the namespace checks
   * correctly. */
  const ALL_SVG_TAGS = addToSet({}, [...svg$1, ...svgFilters, ...svgDisallowed]);
  const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
  /**
   * @param element a DOM element whose namespace is being checked
   * @returns Return false if the element has a
   *  namespace that a spec-compliant parser would never
   *  return. Return true otherwise.
   */
  const _checkValidNamespace = function _checkValidNamespace(element) {
    let parent = getParentNode(element);
    // In JSDOM, if we're inside shadow DOM, then parentNode
    // can be null. We just simulate parent in this case.
    if (!parent || !parent.tagName) {
      parent = {
        namespaceURI: NAMESPACE,
        tagName: 'template'
      };
    }
    const tagName = stringToLowerCase(element.tagName);
    const parentTagName = stringToLowerCase(parent.tagName);
    if (!ALLOWED_NAMESPACES[element.namespaceURI]) {
      return false;
    }
    if (element.namespaceURI === SVG_NAMESPACE) {
      // The only way to switch from HTML namespace to SVG
      // is via <svg>. If it happens via any other tag, then
      // it should be killed.
      if (parent.namespaceURI === HTML_NAMESPACE) {
        return tagName === 'svg';
      }
      // The only way to switch from MathML to SVG is via`
      // svg if parent is either <annotation-xml> or MathML
      // text integration points.
      if (parent.namespaceURI === MATHML_NAMESPACE) {
        return tagName === 'svg' && (parentTagName === 'annotation-xml' || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
      }
      // We only allow elements that are defined in SVG
      // spec. All others are disallowed in SVG namespace.
      return Boolean(ALL_SVG_TAGS[tagName]);
    }
    if (element.namespaceURI === MATHML_NAMESPACE) {
      // The only way to switch from HTML namespace to MathML
      // is via <math>. If it happens via any other tag, then
      // it should be killed.
      if (parent.namespaceURI === HTML_NAMESPACE) {
        return tagName === 'math';
      }
      // The only way to switch from SVG to MathML is via
      // <math> and HTML integration points
      if (parent.namespaceURI === SVG_NAMESPACE) {
        return tagName === 'math' && HTML_INTEGRATION_POINTS[parentTagName];
      }
      // We only allow elements that are defined in MathML
      // spec. All others are disallowed in MathML namespace.
      return Boolean(ALL_MATHML_TAGS[tagName]);
    }
    if (element.namespaceURI === HTML_NAMESPACE) {
      // The only way to switch from SVG to HTML is via
      // HTML integration points, and from MathML to HTML
      // is via MathML text integration points
      if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) {
        return false;
      }
      if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) {
        return false;
      }
      // We disallow tags that are specific for MathML
      // or SVG and should never appear in HTML namespace
      return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
    }
    // For XHTML and XML documents that support custom namespaces
    if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && ALLOWED_NAMESPACES[element.namespaceURI]) {
      return true;
    }
    // The code should never reach this place (this means
    // that the element somehow got namespace that is not
    // HTML, SVG, MathML or allowed via ALLOWED_NAMESPACES).
    // Return false just in case.
    return false;
  };
  /**
   * _forceRemove
   *
   * @param node a DOM node
   */
  const _forceRemove = function _forceRemove(node) {
    arrayPush(DOMPurify.removed, {
      element: node
    });
    try {
      // eslint-disable-next-line unicorn/prefer-dom-node-remove
      getParentNode(node).removeChild(node);
    } catch (_) {
      remove(node);
    }
  };
  /**
   * _removeAttribute
   *
   * @param name an Attribute name
   * @param element a DOM node
   */
  const _removeAttribute = function _removeAttribute(name, element) {
    try {
      arrayPush(DOMPurify.removed, {
        attribute: element.getAttributeNode(name),
        from: element
      });
    } catch (_) {
      arrayPush(DOMPurify.removed, {
        attribute: null,
        from: element
      });
    }
    element.removeAttribute(name);
    // We void attribute values for unremovable "is" attributes
    if (name === 'is') {
      if (RETURN_DOM || RETURN_DOM_FRAGMENT) {
        try {
          _forceRemove(element);
        } catch (_) {}
      } else {
        try {
          element.setAttribute(name, '');
        } catch (_) {}
      }
    }
  };
  /**
   * _initDocument
   *
   * @param dirty - a string of dirty markup
   * @return a DOM, filled with the dirty markup
   */
  const _initDocument = function _initDocument(dirty) {
    /* Create a HTML document */
    let doc = null;
    let leadingWhitespace = null;
    if (FORCE_BODY) {
      dirty = '<remove></remove>' + dirty;
    } else {
      /* If FORCE_BODY isn't used, leading whitespace needs to be preserved manually */
      const matches = stringMatch(dirty, /^[\r\n\t ]+/);
      leadingWhitespace = matches && matches[0];
    }
    if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && NAMESPACE === HTML_NAMESPACE) {
      // Root of XHTML doc must contain xmlns declaration (see https://www.w3.org/TR/xhtml1/normative.html#strict)
      dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + '</body></html>';
    }
    const dirtyPayload = trustedTypesPolicy ? trustedTypesPolicy.createHTML(dirty) : dirty;
    /*
     * Use the DOMParser API by default, fallback later if needs be
     * DOMParser not work for svg when has multiple root element.
     */
    if (NAMESPACE === HTML_NAMESPACE) {
      try {
        doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
      } catch (_) {}
    }
    /* Use createHTMLDocument in case DOMParser is not available */
    if (!doc || !doc.documentElement) {
      doc = implementation.createDocument(NAMESPACE, 'template', null);
      try {
        doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
      } catch (_) {
        // Syntax error if dirtyPayload is invalid xml
      }
    }
    const body = doc.body || doc.documentElement;
    if (dirty && leadingWhitespace) {
      body.insertBefore(document.createTextNode(leadingWhitespace), body.childNodes[0] || null);
    }
    /* Work on whole document or just its body */
    if (NAMESPACE === HTML_NAMESPACE) {
      return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? 'html' : 'body')[0];
    }
    return WHOLE_DOCUMENT ? doc.documentElement : body;
  };
  /**
   * Creates a NodeIterator object that you can use to traverse filtered lists of nodes or elements in a document.
   *
   * @param root The root element or node to start traversing on.
   * @return The created NodeIterator
   */
  const _createNodeIterator = function _createNodeIterator(root) {
    return createNodeIterator.call(root.ownerDocument || root, root,
    // eslint-disable-next-line no-bitwise
    NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
  };
  /**
   * _isClobbered
   *
   * @param element element to check for clobbering attacks
   * @return true if clobbered, false if safe
   */
  const _isClobbered = function _isClobbered(element) {
    return element instanceof HTMLFormElement && (typeof element.nodeName !== 'string' || typeof element.textContent !== 'string' || typeof element.removeChild !== 'function' || !(element.attributes instanceof NamedNodeMap) || typeof element.removeAttribute !== 'function' || typeof element.setAttribute !== 'function' || typeof element.namespaceURI !== 'string' || typeof element.insertBefore !== 'function' || typeof element.hasChildNodes !== 'function');
  };
  /**
   * Checks whether the given object is a DOM node.
   *
   * @param value object to check whether it's a DOM node
   * @return true is object is a DOM node
   */
  const _isNode = function _isNode(value) {
    return typeof Node === 'function' && value instanceof Node;
  };
  function _executeHooks(hooks, currentNode, data) {
    arrayForEach(hooks, hook => {
      hook.call(DOMPurify, currentNode, data, CONFIG);
    });
  }
  /**
   * _sanitizeElements
   *
   * @protect nodeName
   * @protect textContent
   * @protect removeChild
   * @param currentNode to check for permission to exist
   * @return true if node was killed, false if left alive
   */
  const _sanitizeElements = function _sanitizeElements(currentNode) {
    let content = null;
    /* Execute a hook if present */
    _executeHooks(hooks.beforeSanitizeElements, currentNode, null);
    /* Check if element is clobbered or can clobber */
    if (_isClobbered(currentNode)) {
      _forceRemove(currentNode);
      return true;
    }
    /* Now let's check the element's type and name */
    const tagName = transformCaseFunc(currentNode.nodeName);
    /* Execute a hook if present */
    _executeHooks(hooks.uponSanitizeElement, currentNode, {
      tagName,
      allowedTags: ALLOWED_TAGS
    });
    /* Detect mXSS attempts abusing namespace confusion */
    if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(/<[/\w!]/g, currentNode.innerHTML) && regExpTest(/<[/\w!]/g, currentNode.textContent)) {
      _forceRemove(currentNode);
      return true;
    }
    /* Remove any occurrence of processing instructions */
    if (currentNode.nodeType === NODE_TYPE.progressingInstruction) {
      _forceRemove(currentNode);
      return true;
    }
    /* Remove any kind of possibly harmful comments */
    if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(/<[/\w]/g, currentNode.data)) {
      _forceRemove(currentNode);
      return true;
    }
    /* Remove element if anything forbids its presence */
    if (!(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName])) {
      /* Check if we have a custom element to handle */
      if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
        if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) {
          return false;
        }
        if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) {
          return false;
        }
      }
      /* Keep content except for bad-listed elements */
      if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
        const parentNode = getParentNode(currentNode) || currentNode.parentNode;
        const childNodes = getChildNodes(currentNode) || currentNode.childNodes;
        if (childNodes && parentNode) {
          const childCount = childNodes.length;
          for (let i = childCount - 1; i >= 0; --i) {
            const childClone = cloneNode(childNodes[i], true);
            childClone.__removalCount = (currentNode.__removalCount || 0) + 1;
            parentNode.insertBefore(childClone, getNextSibling(currentNode));
          }
        }
      }
      _forceRemove(currentNode);
      return true;
    }
    /* Check whether element has a valid namespace */
    if (currentNode instanceof Element && !_checkValidNamespace(currentNode)) {
      _forceRemove(currentNode);
      return true;
    }
    /* Make sure that older browsers don't get fallback-tag mXSS */
    if ((tagName === 'noscript' || tagName === 'noembed' || tagName === 'noframes') && regExpTest(/<\/no(script|embed|frames)/i, currentNode.innerHTML)) {
      _forceRemove(currentNode);
      return true;
    }
    /* Sanitize element content to be template-safe */
    if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
      /* Get the element's text content */
      content = currentNode.textContent;
      arrayForEach([MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR], expr => {
        content = stringReplace(content, expr, ' ');
      });
      if (currentNode.textContent !== content) {
        arrayPush(DOMPurify.removed, {
          element: currentNode.cloneNode()
        });
        currentNode.textContent = content;
      }
    }
    /* Execute a hook if present */
    _executeHooks(hooks.afterSanitizeElements, currentNode, null);
    return false;
  };
  /**
   * _isValidAttribute
   *
   * @param lcTag Lowercase tag name of containing element.
   * @param lcName Lowercase attribute name.
   * @param value Attribute value.
   * @return Returns true if `value` is valid, otherwise false.
   */
  // eslint-disable-next-line complexity
  const _isValidAttribute = function _isValidAttribute(lcTag, lcName, value) {
    /* Make sure attribute cannot clobber */
    if (SANITIZE_DOM && (lcName === 'id' || lcName === 'name') && (value in document || value in formElement)) {
      return false;
    }
    /* Allow valid data-* attributes: At least one character after "-"
        (https://html.spec.whatwg.org/multipage/dom.html#embedding-custom-non-visible-data-with-the-data-*-attributes)
        XML-compatible (https://html.spec.whatwg.org/multipage/infrastructure.html#xml-compatible and http://www.w3.org/TR/xml/#d0e804)
        We don't need to check the value; it's always URI safe. */
    if (ALLOW_DATA_ATTR && !FORBID_ATTR[lcName] && regExpTest(DATA_ATTR, lcName)) ; else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR, lcName)) ; else if (EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag)) ; else if (!ALLOWED_ATTR[lcName] || FORBID_ATTR[lcName]) {
      if (
      // First condition does a very basic check if a) it's basically a valid custom element tagname AND
      // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
      // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
      _isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName, lcTag)) ||
      // Alternative, second condition checks if it's an `is`-attribute, AND
      // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
      lcName === 'is' && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value))) ; else {
        return false;
      }
      /* Check value is safe. First, is attr inert? If so, is safe */
    } else if (URI_SAFE_ATTRIBUTES[lcName]) ; else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE, ''))) ; else if ((lcName === 'src' || lcName === 'xlink:href' || lcName === 'href') && lcTag !== 'script' && stringIndexOf(value, 'data:') === 0 && DATA_URI_TAGS[lcTag]) ; else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA, stringReplace(value, ATTR_WHITESPACE, ''))) ; else if (value) {
      return false;
    } else ;
    return true;
  };
  /**
   * _isBasicCustomElement
   * checks if at least one dash is included in tagName, and it's not the first char
   * for more sophisticated checking see https://github.com/sindresorhus/validate-element-name
   *
   * @param tagName name of the tag of the node to sanitize
   * @returns Returns true if the tag name meets the basic criteria for a custom element, otherwise false.
   */
  const _isBasicCustomElement = function _isBasicCustomElement(tagName) {
    return tagName !== 'annotation-xml' && stringMatch(tagName, CUSTOM_ELEMENT);
  };
  /**
   * _sanitizeAttributes
   *
   * @protect attributes
   * @protect nodeName
   * @protect removeAttribute
   * @protect setAttribute
   *
   * @param currentNode to sanitize
   */
  const _sanitizeAttributes = function _sanitizeAttributes(currentNode) {
    /* Execute a hook if present */
    _executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
    const {
      attributes
    } = currentNode;
    /* Check if we have attributes; if not we might have a text node */
    if (!attributes || _isClobbered(currentNode)) {
      return;
    }
    const hookEvent = {
      attrName: '',
      attrValue: '',
      keepAttr: true,
      allowedAttributes: ALLOWED_ATTR,
      forceKeepAttr: undefined
    };
    let l = attributes.length;
    /* Go backwards over all attributes; safely remove bad ones */
    while (l--) {
      const attr = attributes[l];
      const {
        name,
        namespaceURI,
        value: attrValue
      } = attr;
      const lcName = transformCaseFunc(name);
      const initValue = attrValue;
      let value = name === 'value' ? initValue : stringTrim(initValue);
      /* Execute a hook if present */
      hookEvent.attrName = lcName;
      hookEvent.attrValue = value;
      hookEvent.keepAttr = true;
      hookEvent.forceKeepAttr = undefined; // Allows developers to see this is a property they can set
      _executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
      value = hookEvent.attrValue;
      /* Full DOM Clobbering protection via namespace isolation,
       * Prefix id and name attributes with `user-content-`
       */
      if (SANITIZE_NAMED_PROPS && (lcName === 'id' || lcName === 'name')) {
        // Remove the attribute with this value
        _removeAttribute(name, currentNode);
        // Prefix the value and later re-create the attribute with the sanitized value
        value = SANITIZE_NAMED_PROPS_PREFIX + value;
      }
      /* Work around a security issue with comments inside attributes */
      if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|title|textarea)/i, value)) {
        _removeAttribute(name, currentNode);
        continue;
      }
      /* Make sure we cannot easily use animated hrefs, even if animations are allowed */
      if (lcName === 'attributename' && stringMatch(value, 'href')) {
        _removeAttribute(name, currentNode);
        continue;
      }
      /* Did the hooks approve of the attribute? */
      if (hookEvent.forceKeepAttr) {
        continue;
      }
      /* Did the hooks approve of the attribute? */
      if (!hookEvent.keepAttr) {
        _removeAttribute(name, currentNode);
        continue;
      }
      /* Work around a security issue in jQuery 3.0 */
      if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(/\/>/i, value)) {
        _removeAttribute(name, currentNode);
        continue;
      }
      /* Sanitize attribute content to be template-safe */
      if (SAFE_FOR_TEMPLATES) {
        arrayForEach([MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR], expr => {
          value = stringReplace(value, expr, ' ');
        });
      }
      /* Is `value` valid for this attribute? */
      const lcTag = transformCaseFunc(currentNode.nodeName);
      if (!_isValidAttribute(lcTag, lcName, value)) {
        _removeAttribute(name, currentNode);
        continue;
      }
      /* Handle attributes that require Trusted Types */
      if (trustedTypesPolicy && typeof trustedTypes === 'object' && typeof trustedTypes.getAttributeType === 'function') {
        if (namespaceURI) ; else {
          switch (trustedTypes.getAttributeType(lcTag, lcName)) {
            case 'TrustedHTML':
              {
                value = trustedTypesPolicy.createHTML(value);
                break;
              }
            case 'TrustedScriptURL':
              {
                value = trustedTypesPolicy.createScriptURL(value);
                break;
              }
          }
        }
      }
      /* Handle invalid data-* attribute set by try-catching it */
      if (value !== initValue) {
        try {
          if (namespaceURI) {
            currentNode.setAttributeNS(namespaceURI, name, value);
          } else {
            /* Fallback to setAttribute() for browser-unrecognized namespaces e.g. "x-schema". */
            currentNode.setAttribute(name, value);
          }
          if (_isClobbered(currentNode)) {
            _forceRemove(currentNode);
          } else {
            arrayPop(DOMPurify.removed);
          }
        } catch (_) {
          _removeAttribute(name, currentNode);
        }
      }
    }
    /* Execute a hook if present */
    _executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
  };
  /**
   * _sanitizeShadowDOM
   *
   * @param fragment to iterate over recursively
   */
  const _sanitizeShadowDOM = function _sanitizeShadowDOM(fragment) {
    let shadowNode = null;
    const shadowIterator = _createNodeIterator(fragment);
    /* Execute a hook if present */
    _executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
    while (shadowNode = shadowIterator.nextNode()) {
      /* Execute a hook if present */
      _executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
      /* Sanitize tags and elements */
      _sanitizeElements(shadowNode);
      /* Check attributes next */
      _sanitizeAttributes(shadowNode);
      /* Deep shadow DOM detected */
      if (shadowNode.content instanceof DocumentFragment) {
        _sanitizeShadowDOM(shadowNode.content);
      }
    }
    /* Execute a hook if present */
    _executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
  };
  // eslint-disable-next-line complexity
  DOMPurify.sanitize = function (dirty) {
    let cfg = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    let body = null;
    let importedNode = null;
    let currentNode = null;
    let returnNode = null;
    /* Make sure we have a string to sanitize.
      DO NOT return early, as this will return the wrong type if
      the user has requested a DOM object rather than a string */
    IS_EMPTY_INPUT = !dirty;
    if (IS_EMPTY_INPUT) {
      dirty = '<!-->';
    }
    /* Stringify, in case dirty is an object */
    if (typeof dirty !== 'string' && !_isNode(dirty)) {
      if (typeof dirty.toString === 'function') {
        dirty = dirty.toString();
        if (typeof dirty !== 'string') {
          throw typeErrorCreate('dirty is not a string, aborting');
        }
      } else {
        throw typeErrorCreate('toString is not a function');
      }
    }
    /* Return dirty HTML if DOMPurify cannot run */
    if (!DOMPurify.isSupported) {
      return dirty;
    }
    /* Assign config vars */
    if (!SET_CONFIG) {
      _parseConfig(cfg);
    }
    /* Clean up removed elements */
    DOMPurify.removed = [];
    /* Check if dirty is correctly typed for IN_PLACE */
    if (typeof dirty === 'string') {
      IN_PLACE = false;
    }
    if (IN_PLACE) {
      /* Do some early pre-sanitization to avoid unsafe root nodes */
      if (dirty.nodeName) {
        const tagName = transformCaseFunc(dirty.nodeName);
        if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
          throw typeErrorCreate('root node is forbidden and cannot be sanitized in-place');
        }
      }
    } else if (dirty instanceof Node) {
      /* If dirty is a DOM element, append to an empty document to avoid
         elements being stripped by the parser */
      body = _initDocument('<!---->');
      importedNode = body.ownerDocument.importNode(dirty, true);
      if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === 'BODY') {
        /* Node is already a body, use as is */
        body = importedNode;
      } else if (importedNode.nodeName === 'HTML') {
        body = importedNode;
      } else {
        // eslint-disable-next-line unicorn/prefer-dom-node-append
        body.appendChild(importedNode);
      }
    } else {
      /* Exit directly if we have nothing to do */
      if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT &&
      // eslint-disable-next-line unicorn/prefer-includes
      dirty.indexOf('<') === -1) {
        return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(dirty) : dirty;
      }
      /* Initialize the document to work on */
      body = _initDocument(dirty);
      /* Check we have a DOM node from the data */
      if (!body) {
        return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : '';
      }
    }
    /* Remove first element node (ours) if FORCE_BODY is set */
    if (body && FORCE_BODY) {
      _forceRemove(body.firstChild);
    }
    /* Get node iterator */
    const nodeIterator = _createNodeIterator(IN_PLACE ? dirty : body);
    /* Now start iterating over the created document */
    while (currentNode = nodeIterator.nextNode()) {
      /* Sanitize tags and elements */
      _sanitizeElements(currentNode);
      /* Check attributes next */
      _sanitizeAttributes(currentNode);
      /* Shadow DOM detected, sanitize it */
      if (currentNode.content instanceof DocumentFragment) {
        _sanitizeShadowDOM(currentNode.content);
      }
    }
    /* If we sanitized `dirty` in-place, return it. */
    if (IN_PLACE) {
      return dirty;
    }
    /* Return sanitized string or DOM */
    if (RETURN_DOM) {
      if (RETURN_DOM_FRAGMENT) {
        returnNode = createDocumentFragment.call(body.ownerDocument);
        while (body.firstChild) {
          // eslint-disable-next-line unicorn/prefer-dom-node-append
          returnNode.appendChild(body.firstChild);
        }
      } else {
        returnNode = body;
      }
      if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) {
        /*
          AdoptNode() is not used because internal state is not reset
          (e.g. the past names map of a HTMLFormElement), this is safe
          in theory but we would rather not risk another attack vector.
          The state that is cloned by importNode() is explicitly defined
          by the specs.
        */
        returnNode = importNode.call(originalDocument, returnNode, true);
      }
      return returnNode;
    }
    let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
    /* Serialize doctype if allowed */
    if (WHOLE_DOCUMENT && ALLOWED_TAGS['!doctype'] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) {
      serializedHTML = '<!DOCTYPE ' + body.ownerDocument.doctype.name + '>\n' + serializedHTML;
    }
    /* Sanitize final string template-safe */
    if (SAFE_FOR_TEMPLATES) {
      arrayForEach([MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR], expr => {
        serializedHTML = stringReplace(serializedHTML, expr, ' ');
      });
    }
    return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(serializedHTML) : serializedHTML;
  };
  DOMPurify.setConfig = function () {
    let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    _parseConfig(cfg);
    SET_CONFIG = true;
  };
  DOMPurify.clearConfig = function () {
    CONFIG = null;
    SET_CONFIG = false;
  };
  DOMPurify.isValidAttribute = function (tag, attr, value) {
    /* Initialize shared config vars if necessary. */
    if (!CONFIG) {
      _parseConfig({});
    }
    const lcTag = transformCaseFunc(tag);
    const lcName = transformCaseFunc(attr);
    return _isValidAttribute(lcTag, lcName, value);
  };
  DOMPurify.addHook = function (entryPoint, hookFunction) {
    if (typeof hookFunction !== 'function') {
      return;
    }
    arrayPush(hooks[entryPoint], hookFunction);
  };
  DOMPurify.removeHook = function (entryPoint, hookFunction) {
    if (hookFunction !== undefined) {
      const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
      return index === -1 ? undefined : arraySplice(hooks[entryPoint], index, 1)[0];
    }
    return arrayPop(hooks[entryPoint]);
  };
  DOMPurify.removeHooks = function (entryPoint) {
    hooks[entryPoint] = [];
  };
  DOMPurify.removeAllHooks = function () {
    hooks = _createHooksMap();
  };
  return DOMPurify;
}
var purify = createDOMPurify();

/**
 * TLDR Extension - Article Extractor
 * Uses Readability.js to extract article content from web pages
 */


/**
 * Estimate reading time in minutes
 * @param {string} text - Article text
 * @returns {number} Reading time in minutes
 */
function estimateReadingTime(text) {
  const wordsPerMinute = 200;
  const wordCount = text.trim().split(/\s+/).length;
  return Math.ceil(wordCount / wordsPerMinute);
}

/**
 * Extract the domain name from URL
 * @param {string} url - Full URL
 * @returns {string} Domain name
 */
function extractDomain(url) {
  try {
    const hostname = new URL(url).hostname;
    return hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

/**
 * Extract article content from the current page
 * @returns {Object} Extraction result with success status and data/error
 */
function extractArticle() {
  try {
    // Check if page is likely an article
    if (!readability.isProbablyReaderable(document)) {
      return {
        success: false,
        error: 'not_article',
        message: "This page doesn't appear to be an article",
      };
    }

    // Clone document to avoid modifying the page
    const documentClone = document.cloneNode(true);

    // Remove script and style tags from clone
    const elementsToRemove = documentClone.querySelectorAll(
      'script, style, noscript, iframe'
    );
    elementsToRemove.forEach((el) => el.remove());

    // Extract article using Readability
    const reader = new readability.Readability(documentClone, {
      charThreshold: 100, // Lower threshold for shorter articles
      keepClasses: false,
      nbTopCandidates: 5,
    });

    const article = reader.parse();

    if (!article || !article.textContent) {
      return {
        success: false,
        error: 'extraction_failed',
        message: 'Could not extract article content',
      };
    }

    // Check minimum content length
    const textContent = article.textContent.trim();
    if (textContent.length < 100) {
      return {
        success: false,
        error: 'not_article',
        message: 'Article content is too short',
      };
    }

    // Sanitize content
    const sanitizedTitle = purify.sanitize(article.title || document.title, {
      ALLOWED_TAGS: [],
    });

    // Build result
    const result = {
      title: sanitizedTitle || 'Untitled',
      content: textContent,
      excerpt: article.excerpt || textContent.slice(0, 200) + '...',
      byline: article.byline || null,
      siteName: article.siteName || extractDomain(window.location.href),
      url: window.location.href,
      readingTime: estimateReadingTime(textContent),
      wordCount: textContent.split(/\s+/).length,
      lang: article.lang || document.documentElement.lang || 'en',
    };

    return {
      success: true,
      data: result,
    };
  } catch (error) {
    console.error('[TLDR] Extraction error:', error);
    return {
      success: false,
      error: 'extraction_failed',
      message: error.message || 'Unknown extraction error',
    };
  }
}

/**
 * TLDR Extension - Content Script
 * Extracts article content from web pages using Readability
 */


// Expose extraction function globally for popup to call
window.__tldrExtractArticle = extractArticle;

// Also listen for messages from background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXTRACT_ARTICLE') {
    const result = extractArticle();
    sendResponse(result);
  }
  return true;
});

console.log('[TLDR] Content script loaded');
